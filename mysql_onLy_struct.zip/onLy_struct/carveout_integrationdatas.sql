CREATE DATABASE  IF NOT EXISTS `carveout` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `carveout`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: carveout
-- ------------------------------------------------------
-- Server version	5.7.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `integrationdatas`
--

DROP TABLE IF EXISTS `integrationdatas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `integrationdatas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `projetosproduto_id` int(11) DEFAULT NULL,
  `projetosprodutosentrega_id` int(11) DEFAULT NULL,
  `pareto_id` int(11) DEFAULT NULL,
  `EPT` varchar(255) DEFAULT NULL,
  `FixVersions` varchar(255) DEFAULT NULL,
  `AffectsVersions` varchar(255) DEFAULT NULL,
  `Assignee` varchar(255) DEFAULT NULL,
  `Created` varchar(255) DEFAULT NULL,
  `Creator` varchar(255) DEFAULT NULL,
  `Description` varchar(255) DEFAULT NULL,
  `IssueType` varchar(255) DEFAULT NULL,
  `Priority` varchar(255) DEFAULT NULL,
  `Project` varchar(255) DEFAULT NULL,
  `Reporter` varchar(255) DEFAULT NULL,
  `Resolution` varchar(255) DEFAULT NULL,
  `Resolved` varchar(255) DEFAULT NULL,
  `Status` varchar(255) DEFAULT NULL,
  `resumo` longtext,
  `Updated` varchar(255) DEFAULT NULL,
  `ReporteIssue` varchar(255) DEFAULT NULL,
  `ReportData` datetime DEFAULT NULL,
  `ReportRegisters` int(11) DEFAULT NULL,
  `integrado` int(11) DEFAULT NULL,
  `criadoem` datetime DEFAULT NULL,
  `atualizadoem` datetime DEFAULT NULL,
  `importadoem` datetime DEFAULT NULL,
  `ultimaalteracao` datetime DEFAULT NULL,
  `entregastipo_id` int(11) DEFAULT NULL,
  `canal` varchar(45) DEFAULT NULL,
  `datatipo` int(11) DEFAULT NULL,
  `labels` varchar(255) DEFAULT NULL,
  `storypoints` decimal(18,4) DEFAULT NULL,
  `images` longtext,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5772 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-16  7:14:33
