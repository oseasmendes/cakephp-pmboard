CREATE DATABASE  IF NOT EXISTS `carveout` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `carveout`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: carveout
-- ------------------------------------------------------
-- Server version	5.7.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `projetosprodutosentregas`
--

DROP TABLE IF EXISTS `projetosprodutosentregas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projetosprodutosentregas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `referencia` varchar(255) DEFAULT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  `projetosproduto_id` int(11) DEFAULT NULL,
  `sistema_id` int(11) DEFAULT NULL,
  `statusfuncional_id` int(11) DEFAULT NULL,
  `pareto_id` int(11) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `tmpprevisto` decimal(18,4) DEFAULT NULL,
  `unidademedida_id` int(11) DEFAULT NULL,
  `dataprevista` date DEFAULT NULL,
  `datarealizada` datetime DEFAULT NULL,
  `prioridade` int(11) DEFAULT NULL,
  `historico` longtext,
  `justificativa` longtext,
  `responsavel` varchar(255) DEFAULT NULL,
  `ordenacao` int(11) DEFAULT NULL,
  `planolinha` int(11) DEFAULT NULL,
  `fase_id` int(11) DEFAULT NULL,
  `empresa_id` int(11) DEFAULT NULL,
  `ambiente_id` int(11) DEFAULT NULL,
  `ordem` int(11) DEFAULT NULL,
  `servidor` varchar(45) DEFAULT NULL,
  `departamento_id` int(11) DEFAULT NULL,
  `prevdatainicio` date DEFAULT NULL,
  `prevdatafim` date DEFAULT NULL,
  `site` varchar(45) DEFAULT NULL,
  `faseprevista` varchar(45) DEFAULT NULL,
  `predecessora` int(11) DEFAULT NULL,
  `administrativa` tinyint(1) DEFAULT NULL,
  `escoporemocaodata` date DEFAULT NULL,
  `escoporemocao` tinyint(1) DEFAULT NULL,
  `escoporemocaodescricao` longtext,
  `sprintprevista_id` int(11) DEFAULT NULL,
  `sprintoriginal` varchar(255) DEFAULT NULL,
  `sprintentrega` varchar(255) DEFAULT NULL,
  `atendidopor` varchar(255) DEFAULT NULL,
  `sistemasmodulo_id` int(11) DEFAULT NULL,
  `sprintrealizada_id` int(11) DEFAULT NULL,
  `entregastipo_id` int(11) DEFAULT NULL,
  `labels` varchar(255) DEFAULT NULL,
  `storypoints` decimal(18,4) DEFAULT NULL,
  `referenciaid` int(11) DEFAULT NULL,
  `imagensanexadas` longtext,
  `datacriacaooriginal` datetime DEFAULT NULL,
  `datatultimaalteracao` datetime DEFAULT NULL,
  `subtasks` longtext,
  `canal` varchar(45) DEFAULT NULL,
  `taskprincipal` varchar(45) DEFAULT NULL,
  `storypointsreview` decimal(18,4) DEFAULT NULL,
  `sprintanterior` varchar(45) DEFAULT NULL,
  `archivestatus` tinyint(1) DEFAULT NULL,
  `archivedate` date DEFAULT NULL,
  `archivereason` varchar(255) DEFAULT NULL,
  `storypointsbug` decimal(18,4) DEFAULT NULL,
  `frente_id` int(11) DEFAULT NULL,
  `taskmain` int(11) DEFAULT NULL,
  `tasksub` int(11) DEFAULT NULL,
  `who` varchar(45) DEFAULT NULL,
  `comentario` varchar(255) DEFAULT NULL,
  `ultimostatus` date DEFAULT NULL,
  `selecionada` tinyint(1) DEFAULT NULL,
  `kronusplan_id` int(11) DEFAULT NULL,
  `businessunit` varchar(45) DEFAULT NULL,
  `complexidade` varchar(15) DEFAULT NULL,
  `cenario` longtext,
  `gestorrequisitante` varchar(200) DEFAULT NULL,
  `consultore_id` int(11) DEFAULT NULL,
  `dataatribuicao` date DEFAULT NULL,
  `kpi` int(11) DEFAULT NULL,
  `alteradopor` varchar(150) DEFAULT NULL,
  `empresasunidade_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_produtoid` (`projetosproduto_id`),
  KEY `idx_prodentrcreated` (`projetosproduto_id`,`created`,`modified`),
  KEY `idx_entregareferencia` (`referencia`),
  KEY `idx_entregaprincipal` (`taskprincipal`),
  KEY `idx_sprintoriginal` (`sprintoriginal`)
) ENGINE=MyISAM AUTO_INCREMENT=65489 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-16  7:14:57
