CREATE DATABASE  IF NOT EXISTS `carveout` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `carveout`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: carveout
-- ------------------------------------------------------
-- Server version	5.7.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `fivewthreehs`
--

DROP TABLE IF EXISTS `fivewthreehs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fivewthreehs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `programa_id` int(11) DEFAULT NULL,
  `projeto_id` int(11) DEFAULT NULL,
  `projetosproduto_id` int(11) DEFAULT NULL,
  `participante_id` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `wwho` varchar(255) DEFAULT NULL,
  `wwhen` date DEFAULT NULL,
  `wwhat` longtext,
  `wwhere` longtext,
  `wwhy` longtext,
  `hhow` longtext,
  `hhowmany` varchar(45) DEFAULT NULL,
  `hhowmuch` decimal(18,4) DEFAULT NULL,
  `hhowlong` varchar(45) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `statusfuncional_id` int(11) DEFAULT NULL,
  `consultore_id` int(11) DEFAULT NULL,
  `fivewthreehpredecessor` int(11) DEFAULT NULL,
  `acao` varchar(45) DEFAULT NULL,
  `resolvido` date DEFAULT NULL,
  `ata_id` int(11) DEFAULT NULL,
  `empresa_id` int(11) DEFAULT NULL,
  `evento_id` int(11) DEFAULT NULL,
  `fivewthreehstype_id` int(11) DEFAULT NULL,
  `riskflag` tinyint(1) DEFAULT NULL,
  `riskseverity` int(11) DEFAULT NULL,
  `riskprobability` int(11) DEFAULT NULL,
  `riskdescription` varchar(255) DEFAULT NULL,
  `opportflag` tinyint(1) DEFAULT NULL,
  `opportdescription` varchar(255) DEFAULT NULL,
  `originaldate` date DEFAULT NULL,
  `sistema_id` int(11) DEFAULT NULL,
  `sistemasprocesso_id` int(11) DEFAULT NULL,
  `referencia` varchar(45) DEFAULT NULL,
  `projetosprodutosentregaid` int(11) DEFAULT NULL,
  `flag` int(11) DEFAULT NULL,
  `ativo` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=324 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-06-03 22:35:03
