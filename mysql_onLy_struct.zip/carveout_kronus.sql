CREATE DATABASE  IF NOT EXISTS `carveout` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `carveout`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: carveout
-- ------------------------------------------------------
-- Server version	5.7.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `kronus`
--

DROP TABLE IF EXISTS `kronus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kronus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kronusplan_id` int(11) DEFAULT NULL,
  `referencia` varchar(150) DEFAULT NULL,
  `unidade` varchar(45) DEFAULT NULL,
  `seq` int(11) DEFAULT NULL,
  `kickoff` datetime DEFAULT NULL,
  `categoria` varchar(45) DEFAULT NULL,
  `ordem` int(11) DEFAULT NULL,
  `atividade` varchar(255) DEFAULT NULL,
  `duracao` decimal(18,4) DEFAULT NULL,
  `inicio` date DEFAULT NULL,
  `fim` date DEFAULT NULL,
  `predecessora` int(11) DEFAULT NULL,
  `responsavel` varchar(80) DEFAULT NULL,
  `milestone` tinyint(1) DEFAULT NULL,
  `flag_id` varchar(10) DEFAULT NULL,
  `comentarios` longtext,
  `fasenome` varchar(45) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `fase_id` int(11) DEFAULT NULL,
  `unidademedida_id` int(11) DEFAULT NULL,
  `kronuscategorie_id` int(11) DEFAULT NULL,
  `kronusgroup_id` int(11) DEFAULT NULL,
  `agenda` tinyint(1) DEFAULT NULL,
  `ativo` tinyint(1) DEFAULT NULL,
  `nivel` int(11) DEFAULT NULL,
  `edt` varchar(45) DEFAULT NULL,
  `versao` int(11) DEFAULT NULL,
  `referenciaatividade` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=181 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-06-03 22:34:47
