CREATE DATABASE  IF NOT EXISTS `carveout` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `carveout`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: carveout
-- ------------------------------------------------------
-- Server version	5.7.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `calendariosplanos`
--

DROP TABLE IF EXISTS `calendariosplanos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `calendariosplanos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(100) DEFAULT NULL,
  `calendariostipo_id` int(11) DEFAULT NULL,
  `horainicio` datetime DEFAULT NULL,
  `horafim` datetime DEFAULT NULL,
  `horaalmocoinicio` datetime DEFAULT NULL,
  `horaalmocofim` datetime DEFAULT NULL,
  `primeiraparadainicio` datetime DEFAULT NULL,
  `primeiraparadafim` datetime DEFAULT NULL,
  `segundaparadainicio` datetime DEFAULT NULL,
  `segundaparadafim` datetime DEFAULT NULL,
  `terceiraparadainicio` datetime DEFAULT NULL,
  `terceiraparadafim` datetime DEFAULT NULL,
  `quartaparadainicio` datetime DEFAULT NULL,
  `quartaparadafim` datetime DEFAULT NULL,
  `tempoabertura` decimal(18,4) DEFAULT NULL,
  `tempoparadaprogramada` decimal(18,4) DEFAULT NULL,
  `tempodisponivel` decimal(18,4) DEFAULT NULL,
  `considerarcrossday` tinyint(1) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `empresa_id` int(11) DEFAULT NULL,
  `tempoprimeiraparada` varchar(30) DEFAULT NULL,
  `temposegundaparada` varchar(30) DEFAULT NULL,
  `tempoterceiraparada` varchar(30) DEFAULT NULL,
  `tempoquartaparada` varchar(30) DEFAULT NULL,
  `tempoalmocoparada` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-06-03 22:34:35
