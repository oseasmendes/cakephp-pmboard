CREATE DATABASE  IF NOT EXISTS `carveout` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `carveout`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: carveout
-- ------------------------------------------------------
-- Server version	5.7.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `projetossprintsagendas`
--

DROP TABLE IF EXISTS `projetossprintsagendas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projetossprintsagendas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `projetossprint_id` int(11) DEFAULT NULL,
  `sequencia` int(11) DEFAULT NULL,
  `dia` int(11) DEFAULT NULL,
  `data` date DEFAULT NULL,
  `referenciadia` varchar(45) DEFAULT NULL,
  `estimado` decimal(18,4) DEFAULT '0.0000',
  `realizadotasksub` decimal(18,4) DEFAULT '0.0000',
  `realizadotaskmain` decimal(18,4) DEFAULT '0.0000',
  `acumuladotasksub` decimal(18,4) DEFAULT '0.0000',
  `acumuladotaskmain` decimal(18,4) DEFAULT '0.0000',
  `burnupacumsub` decimal(18,4) DEFAULT '0.0000',
  `burnupacummain` decimal(18,4) DEFAULT '0.0000',
  `burnunnplaacummain` decimal(18,4) DEFAULT '0.0000',
  `burnunnplaacumsub` decimal(18,4) DEFAULT '0.0000',
  `estimadounplanned` decimal(18,4) DEFAULT '0.0000',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `estimadoburnup` decimal(18,4) DEFAULT '0.0000',
  `estimadoburnupunplan` decimal(18,4) DEFAULT '0.0000',
  `sprinttotalvalue` decimal(18,4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5745 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-06-03 22:34:45
