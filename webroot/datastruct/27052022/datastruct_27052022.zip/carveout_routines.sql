CREATE DATABASE  IF NOT EXISTS `carveout` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `carveout`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: carveout
-- ------------------------------------------------------
-- Server version	5.7.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `viewpaineltempodisponibel`
--

DROP TABLE IF EXISTS `viewpaineltempodisponibel`;
/*!50001 DROP VIEW IF EXISTS `viewpaineltempodisponibel`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `viewpaineltempodisponibel` AS SELECT 
 1 AS `resumo`,
 1 AS `projeto_id`,
 1 AS `perfil`,
 1 AS `percentual`,
 1 AS `tempo`,
 1 AS `previstorealizado`,
 1 AS `semananumero`,
 1 AS `mes`,
 1 AS `mesnome`,
 1 AS `TmpTotal`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_retroitems`
--

DROP TABLE IF EXISTS `view_retroitems`;
/*!50001 DROP VIEW IF EXISTS `view_retroitems`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_retroitems` AS SELECT 
 1 AS `SprintId`,
 1 AS `SprintNome`,
 1 AS `RetroId`,
 1 AS `DataRetro`,
 1 AS `StatusRetro`,
 1 AS `ResumoRetro`,
 1 AS `referencia`,
 1 AS `ObsRetro`,
 1 AS `RetroCreated`,
 1 AS `ParetoId`,
 1 AS `Pareto`,
 1 AS `ItRetroId`,
 1 AS `ItemResumo`,
 1 AS `geraplanoacao`,
 1 AS `referenciaoriginal`,
 1 AS `classificacao`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_countprojetosriscos`
--

DROP TABLE IF EXISTS `view_countprojetosriscos`;
/*!50001 DROP VIEW IF EXISTS `view_countprojetosriscos`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_countprojetosriscos` AS SELECT 
 1 AS `projetosproduto_id`,
 1 AS `TotalRiscos`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_tasksbugsperstory`
--

DROP TABLE IF EXISTS `view_tasksbugsperstory`;
/*!50001 DROP VIEW IF EXISTS `view_tasksbugsperstory`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_tasksbugsperstory` AS SELECT 
 1 AS `sprid`,
 1 AS `spritemid`,
 1 AS `tasktypeid`,
 1 AS `entrid`,
 1 AS `paretoid`,
 1 AS `referencetaskmain`,
 1 AS `referenceept`,
 1 AS `tasktype`,
 1 AS `BUG`,
 1 AS `TASK`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_retros`
--

DROP TABLE IF EXISTS `view_retros`;
/*!50001 DROP VIEW IF EXISTS `view_retros`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_retros` AS SELECT 
 1 AS `SprintId`,
 1 AS `SprintNome`,
 1 AS `RetroId`,
 1 AS `DataRetro`,
 1 AS `StatusRetro`,
 1 AS `ResumoRetro`,
 1 AS `referencia`,
 1 AS `ObsRetro`,
 1 AS `RetroCreated`,
 1 AS `ParetoId`,
 1 AS `ItRetroId`,
 1 AS `ItemResumo`,
 1 AS `geraplanoacao`,
 1 AS `referenciaoriginal`,
 1 AS `classificacao`,
 1 AS `RtaId`,
 1 AS `recomendacao`,
 1 AS `respons`,
 1 AS `pilar`,
 1 AS `area`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_blockpoints`
--

DROP TABLE IF EXISTS `view_blockpoints`;
/*!50001 DROP VIEW IF EXISTS `view_blockpoints`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_blockpoints` AS SELECT 
 1 AS `prj_id`,
 1 AS `projeto`,
 1 AS `blk_id`,
 1 AS `blockpoint`,
 1 AS `consultor`,
 1 AS `responsavel`,
 1 AS `resolvidoem`,
 1 AS `lancto`,
 1 AS `flw_id`,
 1 AS `dataemissao`,
 1 AS `follow_up`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_sprintanteriorativa`
--

DROP TABLE IF EXISTS `view_sprintanteriorativa`;
/*!50001 DROP VIEW IF EXISTS `view_sprintanteriorativa`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_sprintanteriorativa` AS SELECT 
 1 AS `referencia`,
 1 AS `SprintNome`,
 1 AS `SprintDataPlanning`,
 1 AS `DataInicio`,
 1 AS `Datafim`,
 1 AS `ItSprintId`,
 1 AS `SprintId`,
 1 AS `taskmain`,
 1 AS `tasksub`,
 1 AS `taskprincipal`,
 1 AS `storyppoints`,
 1 AS `storypointsrevised`,
 1 AS `storypointsoriginal`,
 1 AS `descricao`,
 1 AS `produto`,
 1 AS `entrega`,
 1 AS `Kanban`,
 1 AS `datarealizada`,
 1 AS `created`,
 1 AS `datatestelimite`,
 1 AS `horasestimadas`,
 1 AS `planejado`,
 1 AS `prio`,
 1 AS `ultimadataalteracao`,
 1 AS `parkingday`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_sprintallativascompletas`
--

DROP TABLE IF EXISTS `view_sprintallativascompletas`;
/*!50001 DROP VIEW IF EXISTS `view_sprintallativascompletas`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_sprintallativascompletas` AS SELECT 
 1 AS `referencia`,
 1 AS `SprintNome`,
 1 AS `SprintDataPlanning`,
 1 AS `DataInicio`,
 1 AS `Datafim`,
 1 AS `ItSprintId`,
 1 AS `SprintId`,
 1 AS `taskmain`,
 1 AS `tasksub`,
 1 AS `taskprincipal`,
 1 AS `storyppoints`,
 1 AS `storypointsrevised`,
 1 AS `storypointsoriginal`,
 1 AS `descricao`,
 1 AS `projeto`,
 1 AS `produto`,
 1 AS `entrega`,
 1 AS `Kanban`,
 1 AS `datarealizada`,
 1 AS `created`,
 1 AS `planejado`,
 1 AS `prioridade`,
 1 AS `ultimadataalteracao`,
 1 AS `parkingday`,
 1 AS `periodo`,
 1 AS `qte`,
 1 AS `sprintoriginal`,
 1 AS `unidademedida`,
 1 AS `calculoexperimental`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_statusreport_v2_agrupamento`
--

DROP TABLE IF EXISTS `view_statusreport_v2_agrupamento`;
/*!50001 DROP VIEW IF EXISTS `view_statusreport_v2_agrupamento`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_statusreport_v2_agrupamento` AS SELECT 
 1 AS `chave`,
 1 AS `projeto`,
 1 AS `prjDataPrevInicio`,
 1 AS `prjDataPrevFim`,
 1 AS `prjRealizadaFim`,
 1 AS `prodid`,
 1 AS `produto`,
 1 AS `prdStatus`,
 1 AS `prio`,
 1 AS `PrdDataPrevInicio`,
 1 AS `PrdDataPrevFim`,
 1 AS `PrdDataRealizada`,
 1 AS `PmStatusgerencial`,
 1 AS `TotalEpt`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_itensentrantes`
--

DROP TABLE IF EXISTS `view_itensentrantes`;
/*!50001 DROP VIEW IF EXISTS `view_itensentrantes`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_itensentrantes` AS SELECT 
 1 AS `ProjetoId`,
 1 AS `Backlog`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_running_functests_all_v1`
--

DROP TABLE IF EXISTS `view_running_functests_all_v1`;
/*!50001 DROP VIEW IF EXISTS `view_running_functests_all_v1`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_running_functests_all_v1` AS SELECT 
 1 AS `entregaId`,
 1 AS `produtoid`,
 1 AS `referencia`,
 1 AS `descricao`,
 1 AS `Kanban`,
 1 AS `datacriacaooriginal`,
 1 AS `datarealizada`,
 1 AS `prioridade`,
 1 AS `responsavel`,
 1 AS `atendidopor`,
 1 AS `sprintoriginal`,
 1 AS `subtasks`,
 1 AS `tipo`,
 1 AS `aging`,
 1 AS `created`,
 1 AS `modified`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_countprojetospendencias`
--

DROP TABLE IF EXISTS `view_countprojetospendencias`;
/*!50001 DROP VIEW IF EXISTS `view_countprojetospendencias`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_countprojetospendencias` AS SELECT 
 1 AS `projeto_id`,
 1 AS `TotalPendencias`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_summaryepts60d`
--

DROP TABLE IF EXISTS `view_summaryepts60d`;
/*!50001 DROP VIEW IF EXISTS `view_summaryepts60d`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_summaryepts60d` AS SELECT 
 1 AS `descricao`,
 1 AS `lancto`,
 1 AS `lanct_mes`,
 1 AS `dia`,
 1 AS `mes`,
 1 AS `ano`,
 1 AS `EPTs`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_ept_pendencias`
--

DROP TABLE IF EXISTS `view_ept_pendencias`;
/*!50001 DROP VIEW IF EXISTS `view_ept_pendencias`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_ept_pendencias` AS SELECT 
 1 AS `programa`,
 1 AS `projeto`,
 1 AS `produto`,
 1 AS `etr_id`,
 1 AS `ept`,
 1 AS `Kanban`,
 1 AS `sumario`,
 1 AS `datalancto`,
 1 AS `flw_id`,
 1 AS `pendencia`,
 1 AS `responsavel`,
 1 AS `motivo`,
 1 AS `stats`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_projetossprints`
--

DROP TABLE IF EXISTS `view_projetossprints`;
/*!50001 DROP VIEW IF EXISTS `view_projetossprints`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_projetossprints` AS SELECT 
 1 AS `id`,
 1 AS `projeto_id`,
 1 AS `descricao`,
 1 AS `metadasprint`,
 1 AS `datainicio`,
 1 AS `datafim`,
 1 AS `created`,
 1 AS `sprinttipo_id`,
 1 AS `modified`,
 1 AS `data`,
 1 AS `gerenciavel`,
 1 AS `agenda`,
 1 AS `totalstorypointsproposto`,
 1 AS `totalstorypointsentregue`,
 1 AS `numerodesenvolvedores`,
 1 AS `totalestoriasprincipais`,
 1 AS `totalestoriassubtasks`,
 1 AS `totalestoriasprincipaisentregues`,
 1 AS `totalestoriassubtasksentregues`,
 1 AS `PercSErvice`,
 1 AS `numero`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vwprojetosalocprofiles`
--

DROP TABLE IF EXISTS `vwprojetosalocprofiles`;
/*!50001 DROP VIEW IF EXISTS `vwprojetosalocprofiles`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vwprojetosalocprofiles` AS SELECT 
 1 AS `PrjAlocId`,
 1 AS `ProjetoId`,
 1 AS `desalocacaorealizada`,
 1 AS `ConsultorId`,
 1 AS `desalocacaoprevista`,
 1 AS `statusfuncional_id`,
 1 AS `horasdia`,
 1 AS `competencia_id`,
 1 AS `percentual`,
 1 AS `consideracalculocapacidade`,
 1 AS `compentencia`,
 1 AS `nome`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_sprintconsultores`
--

DROP TABLE IF EXISTS `view_sprintconsultores`;
/*!50001 DROP VIEW IF EXISTS `view_sprintconsultores`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_sprintconsultores` AS SELECT 
 1 AS `RefPareto`,
 1 AS `ParetoId`,
 1 AS `RespId`,
 1 AS `codenome`,
 1 AS `EPT`,
 1 AS `Kanban`,
 1 AS `PTS`,
 1 AS `Consultor`,
 1 AS `cargo`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_sprintporprojeto`
--

DROP TABLE IF EXISTS `view_sprintporprojeto`;
/*!50001 DROP VIEW IF EXISTS `view_sprintporprojeto`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_sprintporprojeto` AS SELECT 
 1 AS `projeto`,
 1 AS `TtRefer`,
 1 AS `TotalPt`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_itensentrantesfull`
--

DROP TABLE IF EXISTS `view_itensentrantesfull`;
/*!50001 DROP VIEW IF EXISTS `view_itensentrantesfull`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_itensentrantesfull` AS SELECT 
 1 AS `id`,
 1 AS `referencia`,
 1 AS `descricao`,
 1 AS `projetosproduto_id`,
 1 AS `sistema_id`,
 1 AS `statusfuncional_id`,
 1 AS `pareto_id`,
 1 AS `created`,
 1 AS `modified`,
 1 AS `tmpprevisto`,
 1 AS `unidademedida_id`,
 1 AS `dataprevista`,
 1 AS `datarealizada`,
 1 AS `prioridade`,
 1 AS `historico`,
 1 AS `justificativa`,
 1 AS `responsavel`,
 1 AS `ordenacao`,
 1 AS `planolinha`,
 1 AS `fase_id`,
 1 AS `empresa_id`,
 1 AS `ambiente_id`,
 1 AS `ordem`,
 1 AS `servidor`,
 1 AS `departamento_id`,
 1 AS `prevdatainicio`,
 1 AS `prevdatafim`,
 1 AS `site`,
 1 AS `faseprevista`,
 1 AS `predecessora`,
 1 AS `administrativa`,
 1 AS `escoporemocaodata`,
 1 AS `escoporemocao`,
 1 AS `escoporemocaodescricao`,
 1 AS `sprintprevista_id`,
 1 AS `sprintoriginal`,
 1 AS `sprintentrega`,
 1 AS `atendidopor`,
 1 AS `sistemasmodulo_id`,
 1 AS `sprintrealizada_id`,
 1 AS `entregastipo_id`,
 1 AS `labels`,
 1 AS `storypoints`,
 1 AS `referenciaid`,
 1 AS `imagensanexadas`,
 1 AS `datacriacaooriginal`,
 1 AS `datatultimaalteracao`,
 1 AS `subtasks`,
 1 AS `canal`,
 1 AS `taskprincipal`,
 1 AS `storypointsreview`,
 1 AS `sprintanterior`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_sprintativa_espec`
--

DROP TABLE IF EXISTS `view_sprintativa_espec`;
/*!50001 DROP VIEW IF EXISTS `view_sprintativa_espec`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_sprintativa_espec` AS SELECT 
 1 AS `referencia`,
 1 AS `SprintNome`,
 1 AS `SprintDataPlanning`,
 1 AS `DataInicio`,
 1 AS `Datafim`,
 1 AS `ItSprintId`,
 1 AS `SprintId`,
 1 AS `taskmain`,
 1 AS `tasksub`,
 1 AS `taskprincipal`,
 1 AS `storyppoints`,
 1 AS `storypointsrevised`,
 1 AS `storypointsoriginal`,
 1 AS `descricao`,
 1 AS `produto`,
 1 AS `entrega`,
 1 AS `Kanban`,
 1 AS `datarealizada`,
 1 AS `created`,
 1 AS `datatestelimite`,
 1 AS `horasestimadas`,
 1 AS `planejado`,
 1 AS `prio`,
 1 AS `ultimadataalteracao`,
 1 AS `parkingday`,
 1 AS `sprintoriginal`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_projetosparetos`
--

DROP TABLE IF EXISTS `view_projetosparetos`;
/*!50001 DROP VIEW IF EXISTS `view_projetosparetos`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_projetosparetos` AS SELECT 
 1 AS `projeto_id`,
 1 AS `previstodatafim`,
 1 AS `codenome`,
 1 AS `UltParId`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_pipeline`
--

DROP TABLE IF EXISTS `view_pipeline`;
/*!50001 DROP VIEW IF EXISTS `view_pipeline`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_pipeline` AS SELECT 
 1 AS `id`,
 1 AS `projeto`,
 1 AS `statusfuncional_id`,
 1 AS `produto`,
 1 AS `prioridade`,
 1 AS `ept`,
 1 AS `descricao`,
 1 AS `tipotask`,
 1 AS `statustask`,
 1 AS `sprintoriginal`,
 1 AS `sprintanterior`,
 1 AS `datatultimaalteracao`,
 1 AS `datarealizada`,
 1 AS `criadopor`,
 1 AS `storypoints`,
 1 AS `storypointsreview`,
 1 AS `Kanban`,
 1 AS `datacriacaooriginal`,
 1 AS `atendidopor`,
 1 AS `labels`,
 1 AS `subtasks`,
 1 AS `taskprincipal`,
 1 AS `created`,
 1 AS `modified`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_groo_lastgroo_qteitems`
--

DROP TABLE IF EXISTS `view_groo_lastgroo_qteitems`;
/*!50001 DROP VIEW IF EXISTS `view_groo_lastgroo_qteitems`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_groo_lastgroo_qteitems` AS SELECT 
 1 AS `PrjId`,
 1 AS `QtyGroo`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_projetosnotas`
--

DROP TABLE IF EXISTS `view_projetosnotas`;
/*!50001 DROP VIEW IF EXISTS `view_projetosnotas`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_projetosnotas` AS SELECT 
 1 AS `programa`,
 1 AS `projeto`,
 1 AS `id`,
 1 AS `descricao`,
 1 AS `created`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_bugsperstory`
--

DROP TABLE IF EXISTS `view_bugsperstory`;
/*!50001 DROP VIEW IF EXISTS `view_bugsperstory`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_bugsperstory` AS SELECT 
 1 AS `sprid`,
 1 AS `spritemid`,
 1 AS `tasktypeid`,
 1 AS `entrid`,
 1 AS `paretoid`,
 1 AS `referencetaskmain`,
 1 AS `referenceept`,
 1 AS `tasktype`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_pendencias`
--

DROP TABLE IF EXISTS `view_pendencias`;
/*!50001 DROP VIEW IF EXISTS `view_pendencias`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_pendencias` AS SELECT 
 1 AS `id`,
 1 AS `programa`,
 1 AS `projeto`,
 1 AS `produto`,
 1 AS `tipo`,
 1 AS `pendencia`,
 1 AS `quem`,
 1 AS `quando`,
 1 AS `acao`,
 1 AS `situacao`,
 1 AS `consultor`,
 1 AS `ciente`,
 1 AS `sistema`,
 1 AS `lancamento`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_sprintsbugs`
--

DROP TABLE IF EXISTS `view_sprintsbugs`;
/*!50001 DROP VIEW IF EXISTS `view_sprintsbugs`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_sprintsbugs` AS SELECT 
 1 AS `projeto`,
 1 AS `produto`,
 1 AS `entrega`,
 1 AS `total`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_consultoresferias`
--

DROP TABLE IF EXISTS `view_consultoresferias`;
/*!50001 DROP VIEW IF EXISTS `view_consultoresferias`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_consultoresferias` AS SELECT 
 1 AS `CldId`,
 1 AS `AgId`,
 1 AS `ano`,
 1 AS `MesNome`,
 1 AS `data`,
 1 AS `MesSerial`,
 1 AS `wek`,
 1 AS `dia`,
 1 AS `dianome`,
 1 AS `TpAgenda`,
 1 AS `ConsultorId`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_statusreport_v3_pivot`
--

DROP TABLE IF EXISTS `view_statusreport_v3_pivot`;
/*!50001 DROP VIEW IF EXISTS `view_statusreport_v3_pivot`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_statusreport_v3_pivot` AS SELECT 
 1 AS `chave`,
 1 AS `projeto`,
 1 AS `prjDataPrevInicio`,
 1 AS `prjDataPrevFim`,
 1 AS `prjRealizadaFim`,
 1 AS `prodid`,
 1 AS `produto`,
 1 AS `prdStatus`,
 1 AS `prio`,
 1 AS `PrdDataPrevInicio`,
 1 AS `PrdDataPrevFim`,
 1 AS `PrdDataRealizada`,
 1 AS `Analisys`,
 1 AS `Develop`,
 1 AS `Tests`,
 1 AS `Done`,
 1 AS `TotalEpt`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_demandas`
--

DROP TABLE IF EXISTS `view_demandas`;
/*!50001 DROP VIEW IF EXISTS `view_demandas`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_demandas` AS SELECT 
 1 AS `ProjId`,
 1 AS `PrioPrj`,
 1 AS `projeto`,
 1 AS `realinicio`,
 1 AS `realfim`,
 1 AS `prodId`,
 1 AS `PrioPrd`,
 1 AS `produto`,
 1 AS `dataprevistainicio`,
 1 AS `dataprevistafim`,
 1 AS `datarealinicio`,
 1 AS `EntrId`,
 1 AS `EPT`,
 1 AS `Estoria`,
 1 AS `storypoints`,
 1 AS `kanban`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_sprintanteriorallativasembug`
--

DROP TABLE IF EXISTS `view_sprintanteriorallativasembug`;
/*!50001 DROP VIEW IF EXISTS `view_sprintanteriorallativasembug`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_sprintanteriorallativasembug` AS SELECT 
 1 AS `referencia`,
 1 AS `SprintNome`,
 1 AS `SprintDataPlanning`,
 1 AS `DataInicio`,
 1 AS `Datafim`,
 1 AS `ItSprintId`,
 1 AS `SprintId`,
 1 AS `taskmain`,
 1 AS `tasksub`,
 1 AS `taskprincipal`,
 1 AS `storyppoints`,
 1 AS `storypointsrevised`,
 1 AS `storypointsoriginal`,
 1 AS `descricao`,
 1 AS `produto`,
 1 AS `entrega`,
 1 AS `Kanban`,
 1 AS `datarealizada`,
 1 AS `created`,
 1 AS `planejado`,
 1 AS `referfull`,
 1 AS `StoryPointsSub`,
 1 AS `prioridade`,
 1 AS `ultimadataalteracao`,
 1 AS `parkingday`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_sprintallativasembug`
--

DROP TABLE IF EXISTS `view_sprintallativasembug`;
/*!50001 DROP VIEW IF EXISTS `view_sprintallativasembug`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_sprintallativasembug` AS SELECT 
 1 AS `referencia`,
 1 AS `SprintNome`,
 1 AS `SprintDataPlanning`,
 1 AS `DataInicio`,
 1 AS `Datafim`,
 1 AS `ItSprintId`,
 1 AS `SprintId`,
 1 AS `taskmain`,
 1 AS `tasksub`,
 1 AS `taskprincipal`,
 1 AS `storyppoints`,
 1 AS `storypointsrevised`,
 1 AS `storypointsoriginal`,
 1 AS `descricao`,
 1 AS `produto`,
 1 AS `entrega`,
 1 AS `Kanban`,
 1 AS `datarealizada`,
 1 AS `created`,
 1 AS `planejado`,
 1 AS `referfull`,
 1 AS `StoryPointsSub`,
 1 AS `prioridade`,
 1 AS `ultimadataalteracao`,
 1 AS `parkingday`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_statusreport_v1`
--

DROP TABLE IF EXISTS `view_statusreport_v1`;
/*!50001 DROP VIEW IF EXISTS `view_statusreport_v1`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_statusreport_v1` AS SELECT 
 1 AS `projid`,
 1 AS `projeto`,
 1 AS `prjDataPrevInicio`,
 1 AS `prjDataPrevFim`,
 1 AS `prjRealizadaFim`,
 1 AS `prodid`,
 1 AS `produto`,
 1 AS `prdStatus`,
 1 AS `prio`,
 1 AS `PrdDataPrevInicio`,
 1 AS `PrdDataPrevFim`,
 1 AS `PrdDataRealizada`,
 1 AS `ept`,
 1 AS `estoria`,
 1 AS `EntrRespond`,
 1 AS `sprintoriginal`,
 1 AS `datacriacaooriginal`,
 1 AS `criado_dia`,
 1 AS `criado_mes`,
 1 AS `criado_ano`,
 1 AS `kanban`,
 1 AS `cor`,
 1 AS `PmStatusgerencial`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_sprintsubtaskunplanned`
--

DROP TABLE IF EXISTS `view_sprintsubtaskunplanned`;
/*!50001 DROP VIEW IF EXISTS `view_sprintsubtaskunplanned`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_sprintsubtaskunplanned` AS SELECT 
 1 AS `referencia`,
 1 AS `SprintNome`,
 1 AS `SprintDataPlanning`,
 1 AS `DataInicio`,
 1 AS `Datafim`,
 1 AS `ItSprintId`,
 1 AS `SprintId`,
 1 AS `taskmain`,
 1 AS `tasksub`,
 1 AS `taskprincipal`,
 1 AS `storyppoints`,
 1 AS `storypointsrevised`,
 1 AS `storypointsoriginal`,
 1 AS `descricao`,
 1 AS `produto`,
 1 AS `entrega`,
 1 AS `Kanban`,
 1 AS `datarealizada`,
 1 AS `created`,
 1 AS `planejado`,
 1 AS `referfull`,
 1 AS `StoryPointsSub`,
 1 AS `prioridade`,
 1 AS `ultimadataalteracao`,
 1 AS `parkingday`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_entregasparetolastid`
--

DROP TABLE IF EXISTS `view_entregasparetolastid`;
/*!50001 DROP VIEW IF EXISTS `view_entregasparetolastid`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_entregasparetolastid` AS SELECT 
 1 AS `projetosprodutosentrega_id`,
 1 AS `UlId`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_contribute_per_sprint`
--

DROP TABLE IF EXISTS `view_contribute_per_sprint`;
/*!50001 DROP VIEW IF EXISTS `view_contribute_per_sprint`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_contribute_per_sprint` AS SELECT 
 1 AS `projetosprodutosentrega_id`,
 1 AS `referencia`,
 1 AS `responsabilidade_id`,
 1 AS `projetossprint_id`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_sprintallativacomexperimentocalculo`
--

DROP TABLE IF EXISTS `view_sprintallativacomexperimentocalculo`;
/*!50001 DROP VIEW IF EXISTS `view_sprintallativacomexperimentocalculo`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_sprintallativacomexperimentocalculo` AS SELECT 
 1 AS `referencia`,
 1 AS `SprintNome`,
 1 AS `SprintDataPlanning`,
 1 AS `DataInicio`,
 1 AS `Datafim`,
 1 AS `ItSprintId`,
 1 AS `SprintId`,
 1 AS `taskmain`,
 1 AS `tasksub`,
 1 AS `taskprincipal`,
 1 AS `storyppoints`,
 1 AS `storypointsrevised`,
 1 AS `storypointsoriginal`,
 1 AS `descricao`,
 1 AS `produto`,
 1 AS `entrega`,
 1 AS `Kanban`,
 1 AS `datarealizada`,
 1 AS `created`,
 1 AS `planejado`,
 1 AS `referfull`,
 1 AS `StoryPointsSub`,
 1 AS `prioridade`,
 1 AS `ultimadataalteracao`,
 1 AS `parkingday`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_sistemasativos`
--

DROP TABLE IF EXISTS `view_sistemasativos`;
/*!50001 DROP VIEW IF EXISTS `view_sistemasativos`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_sistemasativos` AS SELECT 
 1 AS `id`,
 1 AS `codenome`,
 1 AS `prio`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_paretosentregas`
--

DROP TABLE IF EXISTS `view_paretosentregas`;
/*!50001 DROP VIEW IF EXISTS `view_paretosentregas`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_paretosentregas` AS SELECT 
 1 AS `pareto_id`,
 1 AS `dataatualizada`,
 1 AS `projetosprodutosentrega_id`,
 1 AS `ultimoid`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_5w3h_v1`
--

DROP TABLE IF EXISTS `v_5w3h_v1`;
/*!50001 DROP VIEW IF EXISTS `v_5w3h_v1`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `v_5w3h_v1` AS SELECT 
 1 AS `StatusAtiv`,
 1 AS `FiveId`,
 1 AS `Lancto`,
 1 AS `descricao`,
 1 AS `quem`,
 1 AS `quando`,
 1 AS `resolvidoem`,
 1 AS `oque`,
 1 AS `porque`,
 1 AS `como`,
 1 AS `lancadoem`,
 1 AS `acao`,
 1 AS `programa`,
 1 AS `projeto`,
 1 AS `produtocode`,
 1 AS `produtodesc`,
 1 AS `responsavel`,
 1 AS `consultor`,
 1 AS `ProgramaId`,
 1 AS `ProjetoId`,
 1 AS `ParticipanteId`,
 1 AS `ConsultorId`,
 1 AS `ProdutoId`,
 1 AS `StatusId`,
 1 AS `DiasOcorrencia`,
 1 AS `EfetuadoEm`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_retroist`
--

DROP TABLE IF EXISTS `view_retroist`;
/*!50001 DROP VIEW IF EXISTS `view_retroist`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_retroist` AS SELECT 
 1 AS `SprintId`,
 1 AS `SprintNome`,
 1 AS `RetroId`,
 1 AS `DataRetro`,
 1 AS `StatusRetro`,
 1 AS `ResumoRetro`,
 1 AS `referencia`,
 1 AS `ObsRetro`,
 1 AS `RetroCreated`,
 1 AS `ParetoId`,
 1 AS `Pareto`,
 1 AS `ItRetroId`,
 1 AS `ItemResumo`,
 1 AS `geraplanoacao`,
 1 AS `referenciaoriginal`,
 1 AS `classificacao`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_projetosparetosreduzido`
--

DROP TABLE IF EXISTS `view_projetosparetosreduzido`;
/*!50001 DROP VIEW IF EXISTS `view_projetosparetosreduzido`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_projetosparetosreduzido` AS SELECT 
 1 AS `id`,
 1 AS `projeto_id`,
 1 AS `created`,
 1 AS `Kanban`,
 1 AS `Icon`,
 1 AS `agenda`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_projetosprodutosriscos`
--

DROP TABLE IF EXISTS `view_projetosprodutosriscos`;
/*!50001 DROP VIEW IF EXISTS `view_projetosprodutosriscos`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_projetosprodutosriscos` AS SELECT 
 1 AS `id`,
 1 AS `PrjId`,
 1 AS `produto`,
 1 AS `prd_id`,
 1 AS `riscopadrao`,
 1 AS `aplicabilidade`,
 1 AS `probabilidade`,
 1 AS `severidade`,
 1 AS `nivel`,
 1 AS `resumo`,
 1 AS `detalhes`,
 1 AS `indicadorseveridade`,
 1 AS `indicadorprobabilidade`,
 1 AS `created`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_sprinttempodetestes`
--

DROP TABLE IF EXISTS `view_sprinttempodetestes`;
/*!50001 DROP VIEW IF EXISTS `view_sprinttempodetestes`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_sprinttempodetestes` AS SELECT 
 1 AS `sprint`,
 1 AS `datainicio`,
 1 AS `datafim`,
 1 AS `produto`,
 1 AS `projeto`,
 1 AS `TmpTotalTestes`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_sprintsubtasks`
--

DROP TABLE IF EXISTS `view_sprintsubtasks`;
/*!50001 DROP VIEW IF EXISTS `view_sprintsubtasks`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_sprintsubtasks` AS SELECT 
 1 AS `id`,
 1 AS `projetossprint_id`,
 1 AS `projetosprodutosentrega_id`,
 1 AS `referencia`,
 1 AS `taskmain`,
 1 AS `tasksub`,
 1 AS `dataplanning`,
 1 AS `storyppoints`,
 1 AS `statusfuncional_id`,
 1 AS `created`,
 1 AS `modified`,
 1 AS `storypointsrevised`,
 1 AS `datarevised`,
 1 AS `pareto_id`,
 1 AS `datainiciovalidacao`,
 1 AS `taskprincipal`,
 1 AS `subtask`,
 1 AS `storypointsoriginal`,
 1 AS `datarealizada`,
 1 AS `planejado`,
 1 AS `unidademedida`,
 1 AS `datatestelimite`,
 1 AS `datatesteprevista`,
 1 AS `horastestesestimadas`,
 1 AS `storypointsreview`,
 1 AS `prioridade`,
 1 AS `dataultimaalteracao`,
 1 AS `sprintoriginal`,
 1 AS `sprintoriginal_id`,
 1 AS `calculoexperimental`,
 1 AS `canceladoem`,
 1 AS `cancelado`,
 1 AS `canceladomotivo`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_agenda`
--

DROP TABLE IF EXISTS `view_agenda`;
/*!50001 DROP VIEW IF EXISTS `view_agenda`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_agenda` AS SELECT 
 1 AS `seq`,
 1 AS `data`,
 1 AS `mesnome`,
 1 AS `dianome`,
 1 AS `dia`,
 1 AS `mes`,
 1 AS `ano`,
 1 AS `horainicio`,
 1 AS `horafim`,
 1 AS `WeeK`,
 1 AS `diaserial`,
 1 AS `tipoagenda`,
 1 AS `evento`,
 1 AS `projeto`,
 1 AS `atividade`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_projetotimings`
--

DROP TABLE IF EXISTS `view_projetotimings`;
/*!50001 DROP VIEW IF EXISTS `view_projetotimings`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_projetotimings` AS SELECT 
 1 AS `projeto_id`,
 1 AS `descricao`,
 1 AS `datainicio`,
 1 AS `datafim`,
 1 AS `created`,
 1 AS `modified`,
 1 AS `tmpdisponiveldadata`,
 1 AS `tmpdisponiveldehoje`,
 1 AS `tmpaberturadadata`,
 1 AS `tmpaberturaddehoje`,
 1 AS `totaldediasuteisdadata`,
 1 AS `totaldediasuteisdehoje`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_queue_running_functests_v2`
--

DROP TABLE IF EXISTS `view_queue_running_functests_v2`;
/*!50001 DROP VIEW IF EXISTS `view_queue_running_functests_v2`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_queue_running_functests_v2` AS SELECT 
 1 AS `entregaId`,
 1 AS `produtoid`,
 1 AS `referencia`,
 1 AS `descricao`,
 1 AS `Kanban`,
 1 AS `datacriacaooriginal`,
 1 AS `datarealizada`,
 1 AS `prioridade`,
 1 AS `responsavel`,
 1 AS `atendidopor`,
 1 AS `sprintoriginal`,
 1 AS `subtasks`,
 1 AS `tipo`,
 1 AS `aging`,
 1 AS `created`,
 1 AS `modified`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_painelsprints_v0`
--

DROP TABLE IF EXISTS `view_painelsprints_v0`;
/*!50001 DROP VIEW IF EXISTS `view_painelsprints_v0`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_painelsprints_v0` AS SELECT 
 1 AS `sprintoriginal`,
 1 AS `TotalTasks`,
 1 AS `TotalStoryPoints`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_feedbacksprints`
--

DROP TABLE IF EXISTS `view_feedbacksprints`;
/*!50001 DROP VIEW IF EXISTS `view_feedbacksprints`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_feedbacksprints` AS SELECT 
 1 AS `programa`,
 1 AS `sprint`,
 1 AS `projetoid`,
 1 AS `projeto`,
 1 AS `produto`,
 1 AS `datainicio`,
 1 AS `datafim`,
 1 AS `SprItId`,
 1 AS `dataplanning`,
 1 AS `ept`,
 1 AS `descricao`,
 1 AS `kanban`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_kanbanentregas`
--

DROP TABLE IF EXISTS `view_kanbanentregas`;
/*!50001 DROP VIEW IF EXISTS `view_kanbanentregas`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_kanbanentregas` AS SELECT 
 1 AS `produto_id`,
 1 AS `produto`,
 1 AS `prioproduto`,
 1 AS `entrega_id`,
 1 AS `entrega`,
 1 AS `prioentrega`,
 1 AS `entregapareto_id`,
 1 AS `projetosprodutosentrega_id`,
 1 AS `pareto_id`,
 1 AS `Kanban`,
 1 AS `created`,
 1 AS `motivo`,
 1 AS `tmpprevisto`,
 1 AS `dataprevista`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_sprintativa`
--

DROP TABLE IF EXISTS `view_sprintativa`;
/*!50001 DROP VIEW IF EXISTS `view_sprintativa`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_sprintativa` AS SELECT 
 1 AS `referencia`,
 1 AS `SprintNome`,
 1 AS `SprintDataPlanning`,
 1 AS `DataInicio`,
 1 AS `Datafim`,
 1 AS `ItSprintId`,
 1 AS `SprintId`,
 1 AS `taskmain`,
 1 AS `tasksub`,
 1 AS `taskprincipal`,
 1 AS `storyppoints`,
 1 AS `storypointsrevised`,
 1 AS `storypointsoriginal`,
 1 AS `descricao`,
 1 AS `produto`,
 1 AS `entrega`,
 1 AS `Kanban`,
 1 AS `datarealizada`,
 1 AS `created`,
 1 AS `datatestelimite`,
 1 AS `horasestimadas`,
 1 AS `planejado`,
 1 AS `prio`,
 1 AS `ultimadataalteracao`,
 1 AS `parkingday`,
 1 AS `sprintoriginal`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `viewpaineldeferias`
--

DROP TABLE IF EXISTS `viewpaineldeferias`;
/*!50001 DROP VIEW IF EXISTS `viewpaineldeferias`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `viewpaineldeferias` AS SELECT 
 1 AS `resumo`,
 1 AS `projeto_id`,
 1 AS `perfil`,
 1 AS `percentual`,
 1 AS `tempo`,
 1 AS `previstorealizado`,
 1 AS `semananumero`,
 1 AS `mes`,
 1 AS `mesnome`,
 1 AS `TmpTotal`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_queue_sprints_v1`
--

DROP TABLE IF EXISTS `view_queue_sprints_v1`;
/*!50001 DROP VIEW IF EXISTS `view_queue_sprints_v1`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_queue_sprints_v1` AS SELECT 
 1 AS `entregaId`,
 1 AS `produtoid`,
 1 AS `referencia`,
 1 AS `descricao`,
 1 AS `Kanban`,
 1 AS `datacriacaooriginal`,
 1 AS `datarealizada`,
 1 AS `prioridade`,
 1 AS `responsavel`,
 1 AS `atendidopor`,
 1 AS `sprintoriginal`,
 1 AS `subtasks`,
 1 AS `tipo`,
 1 AS `aging`,
 1 AS `created`,
 1 AS `modified`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_prjsprintspontuacao`
--

DROP TABLE IF EXISTS `view_prjsprintspontuacao`;
/*!50001 DROP VIEW IF EXISTS `view_prjsprintspontuacao`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_prjsprintspontuacao` AS SELECT 
 1 AS `sprint`,
 1 AS `EPT`,
 1 AS `Planejado`,
 1 AS `PointReview`,
 1 AS `Revisado`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_paretosentregas`
--

DROP TABLE IF EXISTS `v_paretosentregas`;
/*!50001 DROP VIEW IF EXISTS `v_paretosentregas`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `v_paretosentregas` AS SELECT 
 1 AS `pareto_id`,
 1 AS `dataatualizada`,
 1 AS `projetosprodutosentrega_id`,
 1 AS `ultimoid`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_queue_running_functests`
--

DROP TABLE IF EXISTS `view_queue_running_functests`;
/*!50001 DROP VIEW IF EXISTS `view_queue_running_functests`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_queue_running_functests` AS SELECT 
 1 AS `entregaId`,
 1 AS `produtoid`,
 1 AS `referencia`,
 1 AS `descricao`,
 1 AS `Kanban`,
 1 AS `datacriacaooriginal`,
 1 AS `criacaodia`,
 1 AS `criacaomes`,
 1 AS `criacaoano`,
 1 AS `datarealizada`,
 1 AS `prioridade`,
 1 AS `responsavel`,
 1 AS `atendidopor`,
 1 AS `sprintoriginal`,
 1 AS `subtasks`,
 1 AS `created`,
 1 AS `modified`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_sprintitensprincipais`
--

DROP TABLE IF EXISTS `view_sprintitensprincipais`;
/*!50001 DROP VIEW IF EXISTS `view_sprintitensprincipais`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_sprintitensprincipais` AS SELECT 
 1 AS `id`,
 1 AS `sprid`,
 1 AS `entrid`,
 1 AS `referencia`,
 1 AS `planejado`,
 1 AS `sprintoriginal`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_valorestoriasprincipais`
--

DROP TABLE IF EXISTS `view_valorestoriasprincipais`;
/*!50001 DROP VIEW IF EXISTS `view_valorestoriasprincipais`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_valorestoriasprincipais` AS SELECT 
 1 AS `taskprincipal`,
 1 AS `Estorias`,
 1 AS `Total`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_contribute_per_support`
--

DROP TABLE IF EXISTS `view_contribute_per_support`;
/*!50001 DROP VIEW IF EXISTS `view_contribute_per_support`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_contribute_per_support` AS SELECT 
 1 AS `projetosprodutosentrega_id`,
 1 AS `referencia`,
 1 AS `responsabilidade_id`,
 1 AS `projetossprint_id`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vwentregaultimopareto`
--

DROP TABLE IF EXISTS `vwentregaultimopareto`;
/*!50001 DROP VIEW IF EXISTS `vwentregaultimopareto`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vwentregaultimopareto` AS SELECT 
 1 AS `EntregaId`,
 1 AS `ProdutoId`,
 1 AS `SistemaId`,
 1 AS `StatusId`,
 1 AS `created`,
 1 AS `UnMedidaId`,
 1 AS `prioridade`,
 1 AS `planolinha`,
 1 AS `FaseId`,
 1 AS `EmpresaId`,
 1 AS `AmbienteId`,
 1 AS `ordem`,
 1 AS `DeptoId`,
 1 AS `EntregaParetoId`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_prodentregaultimopareto`
--

DROP TABLE IF EXISTS `v_prodentregaultimopareto`;
/*!50001 DROP VIEW IF EXISTS `v_prodentregaultimopareto`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `v_prodentregaultimopareto` AS SELECT 
 1 AS `EntregaId`,
 1 AS `ParetoId`,
 1 AS `UltAtualizacao`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_sprintporproduto`
--

DROP TABLE IF EXISTS `view_sprintporproduto`;
/*!50001 DROP VIEW IF EXISTS `view_sprintporproduto`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_sprintporproduto` AS SELECT 
 1 AS `produto`,
 1 AS `TtRefer`,
 1 AS `TotalPt`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_sprintmainunplaned`
--

DROP TABLE IF EXISTS `view_sprintmainunplaned`;
/*!50001 DROP VIEW IF EXISTS `view_sprintmainunplaned`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_sprintmainunplaned` AS SELECT 
 1 AS `referencia`,
 1 AS `SprintNome`,
 1 AS `SprintDataPlanning`,
 1 AS `DataInicio`,
 1 AS `Datafim`,
 1 AS `ItSprintId`,
 1 AS `SprintId`,
 1 AS `taskmain`,
 1 AS `tasksub`,
 1 AS `taskprincipal`,
 1 AS `storyppoints`,
 1 AS `storypointsrevised`,
 1 AS `storypointsoriginal`,
 1 AS `descricao`,
 1 AS `produto`,
 1 AS `entrega`,
 1 AS `Kanban`,
 1 AS `datarealizada`,
 1 AS `created`,
 1 AS `datatestelimite`,
 1 AS `horasestimadas`,
 1 AS `planejado`,
 1 AS `prio`,
 1 AS `ultimadataalteracao`,
 1 AS `parkingday`,
 1 AS `sprintoriginal`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_feedbacksprintrequisitos`
--

DROP TABLE IF EXISTS `view_feedbacksprintrequisitos`;
/*!50001 DROP VIEW IF EXISTS `view_feedbacksprintrequisitos`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_feedbacksprintrequisitos` AS SELECT 
 1 AS `SprintNome`,
 1 AS `SprintDataPlanning`,
 1 AS `DataInicio`,
 1 AS `Datafim`,
 1 AS `programa`,
 1 AS `projeto`,
 1 AS `produto`,
 1 AS `entrega`,
 1 AS `referencia`,
 1 AS `Un`,
 1 AS `descricao`,
 1 AS `Kanban`,
 1 AS `datarealizada`,
 1 AS `created`,
 1 AS `datatestelimite`,
 1 AS `horasestimadas`,
 1 AS `planejado`,
 1 AS `prio`,
 1 AS `ultimadataalteracao`,
 1 AS `parkingday`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_painelprints_v1`
--

DROP TABLE IF EXISTS `view_painelprints_v1`;
/*!50001 DROP VIEW IF EXISTS `view_painelprints_v1`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_painelprints_v1` AS SELECT 
 1 AS `produto`,
 1 AS `sprintoriginal`,
 1 AS `TotalTasks`,
 1 AS `TotalStoryPoints`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_queue_no_priorized`
--

DROP TABLE IF EXISTS `view_queue_no_priorized`;
/*!50001 DROP VIEW IF EXISTS `view_queue_no_priorized`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_queue_no_priorized` AS SELECT 
 1 AS `entregaId`,
 1 AS `produtoid`,
 1 AS `referencia`,
 1 AS `descricao`,
 1 AS `Kanban`,
 1 AS `datacriacaooriginal`,
 1 AS `datarealizada`,
 1 AS `prioridade`,
 1 AS `responsavel`,
 1 AS `atendidopor`,
 1 AS `sprintoriginal`,
 1 AS `subtasks`,
 1 AS `tipo`,
 1 AS `aging`,
 1 AS `created`,
 1 AS `modified`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_projetossprintdistpontoskanban`
--

DROP TABLE IF EXISTS `view_projetossprintdistpontoskanban`;
/*!50001 DROP VIEW IF EXISTS `view_projetossprintdistpontoskanban`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_projetossprintdistpontoskanban` AS SELECT 
 1 AS `SprintNome`,
 1 AS `SprintId`,
 1 AS `Kanban`,
 1 AS `TotalPts`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_sprintstoryreview`
--

DROP TABLE IF EXISTS `view_sprintstoryreview`;
/*!50001 DROP VIEW IF EXISTS `view_sprintstoryreview`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_sprintstoryreview` AS SELECT 
 1 AS `projetossprint_id`,
 1 AS `projetosprodutosentrega_id`,
 1 AS `referencia`,
 1 AS `storyppoints`,
 1 AS `storypointsrevised`,
 1 AS `storypointsoriginal`,
 1 AS `storypointsreview`,
 1 AS `planejado`,
 1 AS `StoryPointsFinal`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `viewpaineltempodisponibel`
--

/*!50001 DROP VIEW IF EXISTS `viewpaineltempodisponibel`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `viewpaineltempodisponibel` AS select 1 AS `resumo`,1 AS `projeto_id`,1 AS `perfil`,1 AS `percentual`,1 AS `tempo`,1 AS `previstorealizado`,1 AS `semananumero`,1 AS `mes`,1 AS `mesnome`,1 AS `TmpTotal` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_retroitems`
--

/*!50001 DROP VIEW IF EXISTS `view_retroitems`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_retroitems` AS select 1 AS `SprintId`,1 AS `SprintNome`,1 AS `RetroId`,1 AS `DataRetro`,1 AS `StatusRetro`,1 AS `ResumoRetro`,1 AS `referencia`,1 AS `ObsRetro`,1 AS `RetroCreated`,1 AS `ParetoId`,1 AS `Pareto`,1 AS `ItRetroId`,1 AS `ItemResumo`,1 AS `geraplanoacao`,1 AS `referenciaoriginal`,1 AS `classificacao` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_countprojetosriscos`
--

/*!50001 DROP VIEW IF EXISTS `view_countprojetosriscos`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_countprojetosriscos` AS select 1 AS `projetosproduto_id`,1 AS `TotalRiscos` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_tasksbugsperstory`
--

/*!50001 DROP VIEW IF EXISTS `view_tasksbugsperstory`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_tasksbugsperstory` AS select 1 AS `sprid`,1 AS `spritemid`,1 AS `tasktypeid`,1 AS `entrid`,1 AS `paretoid`,1 AS `referencetaskmain`,1 AS `referenceept`,1 AS `tasktype`,1 AS `BUG`,1 AS `TASK` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_retros`
--

/*!50001 DROP VIEW IF EXISTS `view_retros`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_retros` AS select 1 AS `SprintId`,1 AS `SprintNome`,1 AS `RetroId`,1 AS `DataRetro`,1 AS `StatusRetro`,1 AS `ResumoRetro`,1 AS `referencia`,1 AS `ObsRetro`,1 AS `RetroCreated`,1 AS `ParetoId`,1 AS `ItRetroId`,1 AS `ItemResumo`,1 AS `geraplanoacao`,1 AS `referenciaoriginal`,1 AS `classificacao`,1 AS `RtaId`,1 AS `recomendacao`,1 AS `respons`,1 AS `pilar`,1 AS `area` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_blockpoints`
--

/*!50001 DROP VIEW IF EXISTS `view_blockpoints`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_blockpoints` AS select 1 AS `prj_id`,1 AS `projeto`,1 AS `blk_id`,1 AS `blockpoint`,1 AS `consultor`,1 AS `responsavel`,1 AS `resolvidoem`,1 AS `lancto`,1 AS `flw_id`,1 AS `dataemissao`,1 AS `follow_up` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_sprintanteriorativa`
--

/*!50001 DROP VIEW IF EXISTS `view_sprintanteriorativa`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_sprintanteriorativa` AS select 1 AS `referencia`,1 AS `SprintNome`,1 AS `SprintDataPlanning`,1 AS `DataInicio`,1 AS `Datafim`,1 AS `ItSprintId`,1 AS `SprintId`,1 AS `taskmain`,1 AS `tasksub`,1 AS `taskprincipal`,1 AS `storyppoints`,1 AS `storypointsrevised`,1 AS `storypointsoriginal`,1 AS `descricao`,1 AS `produto`,1 AS `entrega`,1 AS `Kanban`,1 AS `datarealizada`,1 AS `created`,1 AS `datatestelimite`,1 AS `horasestimadas`,1 AS `planejado`,1 AS `prio`,1 AS `ultimadataalteracao`,1 AS `parkingday` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_sprintallativascompletas`
--

/*!50001 DROP VIEW IF EXISTS `view_sprintallativascompletas`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_sprintallativascompletas` AS select 1 AS `referencia`,1 AS `SprintNome`,1 AS `SprintDataPlanning`,1 AS `DataInicio`,1 AS `Datafim`,1 AS `ItSprintId`,1 AS `SprintId`,1 AS `taskmain`,1 AS `tasksub`,1 AS `taskprincipal`,1 AS `storyppoints`,1 AS `storypointsrevised`,1 AS `storypointsoriginal`,1 AS `descricao`,1 AS `projeto`,1 AS `produto`,1 AS `entrega`,1 AS `Kanban`,1 AS `datarealizada`,1 AS `created`,1 AS `planejado`,1 AS `prioridade`,1 AS `ultimadataalteracao`,1 AS `parkingday`,1 AS `periodo`,1 AS `qte`,1 AS `sprintoriginal`,1 AS `unidademedida`,1 AS `calculoexperimental` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_statusreport_v2_agrupamento`
--

/*!50001 DROP VIEW IF EXISTS `view_statusreport_v2_agrupamento`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_statusreport_v2_agrupamento` AS select 1 AS `chave`,1 AS `projeto`,1 AS `prjDataPrevInicio`,1 AS `prjDataPrevFim`,1 AS `prjRealizadaFim`,1 AS `prodid`,1 AS `produto`,1 AS `prdStatus`,1 AS `prio`,1 AS `PrdDataPrevInicio`,1 AS `PrdDataPrevFim`,1 AS `PrdDataRealizada`,1 AS `PmStatusgerencial`,1 AS `TotalEpt` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_itensentrantes`
--

/*!50001 DROP VIEW IF EXISTS `view_itensentrantes`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_itensentrantes` AS select 1 AS `ProjetoId`,1 AS `Backlog` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_running_functests_all_v1`
--

/*!50001 DROP VIEW IF EXISTS `view_running_functests_all_v1`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_running_functests_all_v1` AS select 1 AS `entregaId`,1 AS `produtoid`,1 AS `referencia`,1 AS `descricao`,1 AS `Kanban`,1 AS `datacriacaooriginal`,1 AS `datarealizada`,1 AS `prioridade`,1 AS `responsavel`,1 AS `atendidopor`,1 AS `sprintoriginal`,1 AS `subtasks`,1 AS `tipo`,1 AS `aging`,1 AS `created`,1 AS `modified` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_countprojetospendencias`
--

/*!50001 DROP VIEW IF EXISTS `view_countprojetospendencias`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_countprojetospendencias` AS select 1 AS `projeto_id`,1 AS `TotalPendencias` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_summaryepts60d`
--

/*!50001 DROP VIEW IF EXISTS `view_summaryepts60d`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_summaryepts60d` AS select 1 AS `descricao`,1 AS `lancto`,1 AS `lanct_mes`,1 AS `dia`,1 AS `mes`,1 AS `ano`,1 AS `EPTs` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_ept_pendencias`
--

/*!50001 DROP VIEW IF EXISTS `view_ept_pendencias`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_ept_pendencias` AS select 1 AS `programa`,1 AS `projeto`,1 AS `produto`,1 AS `etr_id`,1 AS `ept`,1 AS `Kanban`,1 AS `sumario`,1 AS `datalancto`,1 AS `flw_id`,1 AS `pendencia`,1 AS `responsavel`,1 AS `motivo`,1 AS `stats` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_projetossprints`
--

/*!50001 DROP VIEW IF EXISTS `view_projetossprints`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_projetossprints` AS select 1 AS `id`,1 AS `projeto_id`,1 AS `descricao`,1 AS `metadasprint`,1 AS `datainicio`,1 AS `datafim`,1 AS `created`,1 AS `sprinttipo_id`,1 AS `modified`,1 AS `data`,1 AS `gerenciavel`,1 AS `agenda`,1 AS `totalstorypointsproposto`,1 AS `totalstorypointsentregue`,1 AS `numerodesenvolvedores`,1 AS `totalestoriasprincipais`,1 AS `totalestoriassubtasks`,1 AS `totalestoriasprincipaisentregues`,1 AS `totalestoriassubtasksentregues`,1 AS `PercSErvice`,1 AS `numero` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vwprojetosalocprofiles`
--

/*!50001 DROP VIEW IF EXISTS `vwprojetosalocprofiles`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vwprojetosalocprofiles` AS select 1 AS `PrjAlocId`,1 AS `ProjetoId`,1 AS `desalocacaorealizada`,1 AS `ConsultorId`,1 AS `desalocacaoprevista`,1 AS `statusfuncional_id`,1 AS `horasdia`,1 AS `competencia_id`,1 AS `percentual`,1 AS `consideracalculocapacidade`,1 AS `compentencia`,1 AS `nome` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_sprintconsultores`
--

/*!50001 DROP VIEW IF EXISTS `view_sprintconsultores`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_sprintconsultores` AS select 1 AS `RefPareto`,1 AS `ParetoId`,1 AS `RespId`,1 AS `codenome`,1 AS `EPT`,1 AS `Kanban`,1 AS `PTS`,1 AS `Consultor`,1 AS `cargo` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_sprintporprojeto`
--

/*!50001 DROP VIEW IF EXISTS `view_sprintporprojeto`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_sprintporprojeto` AS select 1 AS `projeto`,1 AS `TtRefer`,1 AS `TotalPt` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_itensentrantesfull`
--

/*!50001 DROP VIEW IF EXISTS `view_itensentrantesfull`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_itensentrantesfull` AS select 1 AS `id`,1 AS `referencia`,1 AS `descricao`,1 AS `projetosproduto_id`,1 AS `sistema_id`,1 AS `statusfuncional_id`,1 AS `pareto_id`,1 AS `created`,1 AS `modified`,1 AS `tmpprevisto`,1 AS `unidademedida_id`,1 AS `dataprevista`,1 AS `datarealizada`,1 AS `prioridade`,1 AS `historico`,1 AS `justificativa`,1 AS `responsavel`,1 AS `ordenacao`,1 AS `planolinha`,1 AS `fase_id`,1 AS `empresa_id`,1 AS `ambiente_id`,1 AS `ordem`,1 AS `servidor`,1 AS `departamento_id`,1 AS `prevdatainicio`,1 AS `prevdatafim`,1 AS `site`,1 AS `faseprevista`,1 AS `predecessora`,1 AS `administrativa`,1 AS `escoporemocaodata`,1 AS `escoporemocao`,1 AS `escoporemocaodescricao`,1 AS `sprintprevista_id`,1 AS `sprintoriginal`,1 AS `sprintentrega`,1 AS `atendidopor`,1 AS `sistemasmodulo_id`,1 AS `sprintrealizada_id`,1 AS `entregastipo_id`,1 AS `labels`,1 AS `storypoints`,1 AS `referenciaid`,1 AS `imagensanexadas`,1 AS `datacriacaooriginal`,1 AS `datatultimaalteracao`,1 AS `subtasks`,1 AS `canal`,1 AS `taskprincipal`,1 AS `storypointsreview`,1 AS `sprintanterior` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_sprintativa_espec`
--

/*!50001 DROP VIEW IF EXISTS `view_sprintativa_espec`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_sprintativa_espec` AS select 1 AS `referencia`,1 AS `SprintNome`,1 AS `SprintDataPlanning`,1 AS `DataInicio`,1 AS `Datafim`,1 AS `ItSprintId`,1 AS `SprintId`,1 AS `taskmain`,1 AS `tasksub`,1 AS `taskprincipal`,1 AS `storyppoints`,1 AS `storypointsrevised`,1 AS `storypointsoriginal`,1 AS `descricao`,1 AS `produto`,1 AS `entrega`,1 AS `Kanban`,1 AS `datarealizada`,1 AS `created`,1 AS `datatestelimite`,1 AS `horasestimadas`,1 AS `planejado`,1 AS `prio`,1 AS `ultimadataalteracao`,1 AS `parkingday`,1 AS `sprintoriginal` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_projetosparetos`
--

/*!50001 DROP VIEW IF EXISTS `view_projetosparetos`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_projetosparetos` AS select 1 AS `projeto_id`,1 AS `previstodatafim`,1 AS `codenome`,1 AS `UltParId` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_pipeline`
--

/*!50001 DROP VIEW IF EXISTS `view_pipeline`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_pipeline` AS select 1 AS `id`,1 AS `projeto`,1 AS `statusfuncional_id`,1 AS `produto`,1 AS `prioridade`,1 AS `ept`,1 AS `descricao`,1 AS `tipotask`,1 AS `statustask`,1 AS `sprintoriginal`,1 AS `sprintanterior`,1 AS `datatultimaalteracao`,1 AS `datarealizada`,1 AS `criadopor`,1 AS `storypoints`,1 AS `storypointsreview`,1 AS `Kanban`,1 AS `datacriacaooriginal`,1 AS `atendidopor`,1 AS `labels`,1 AS `subtasks`,1 AS `taskprincipal`,1 AS `created`,1 AS `modified` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_groo_lastgroo_qteitems`
--

/*!50001 DROP VIEW IF EXISTS `view_groo_lastgroo_qteitems`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_groo_lastgroo_qteitems` AS select 1 AS `PrjId`,1 AS `QtyGroo` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_projetosnotas`
--

/*!50001 DROP VIEW IF EXISTS `view_projetosnotas`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_projetosnotas` AS select 1 AS `programa`,1 AS `projeto`,1 AS `id`,1 AS `descricao`,1 AS `created` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_bugsperstory`
--

/*!50001 DROP VIEW IF EXISTS `view_bugsperstory`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_bugsperstory` AS select 1 AS `sprid`,1 AS `spritemid`,1 AS `tasktypeid`,1 AS `entrid`,1 AS `paretoid`,1 AS `referencetaskmain`,1 AS `referenceept`,1 AS `tasktype` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_pendencias`
--

/*!50001 DROP VIEW IF EXISTS `view_pendencias`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_pendencias` AS select 1 AS `id`,1 AS `programa`,1 AS `projeto`,1 AS `produto`,1 AS `tipo`,1 AS `pendencia`,1 AS `quem`,1 AS `quando`,1 AS `acao`,1 AS `situacao`,1 AS `consultor`,1 AS `ciente`,1 AS `sistema`,1 AS `lancamento` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_sprintsbugs`
--

/*!50001 DROP VIEW IF EXISTS `view_sprintsbugs`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_sprintsbugs` AS select 1 AS `projeto`,1 AS `produto`,1 AS `entrega`,1 AS `total` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_consultoresferias`
--

/*!50001 DROP VIEW IF EXISTS `view_consultoresferias`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_consultoresferias` AS select 1 AS `CldId`,1 AS `AgId`,1 AS `ano`,1 AS `MesNome`,1 AS `data`,1 AS `MesSerial`,1 AS `wek`,1 AS `dia`,1 AS `dianome`,1 AS `TpAgenda`,1 AS `ConsultorId` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_statusreport_v3_pivot`
--

/*!50001 DROP VIEW IF EXISTS `view_statusreport_v3_pivot`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_statusreport_v3_pivot` AS select 1 AS `chave`,1 AS `projeto`,1 AS `prjDataPrevInicio`,1 AS `prjDataPrevFim`,1 AS `prjRealizadaFim`,1 AS `prodid`,1 AS `produto`,1 AS `prdStatus`,1 AS `prio`,1 AS `PrdDataPrevInicio`,1 AS `PrdDataPrevFim`,1 AS `PrdDataRealizada`,1 AS `Analisys`,1 AS `Develop`,1 AS `Tests`,1 AS `Done`,1 AS `TotalEpt` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_demandas`
--

/*!50001 DROP VIEW IF EXISTS `view_demandas`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_demandas` AS select 1 AS `ProjId`,1 AS `PrioPrj`,1 AS `projeto`,1 AS `realinicio`,1 AS `realfim`,1 AS `prodId`,1 AS `PrioPrd`,1 AS `produto`,1 AS `dataprevistainicio`,1 AS `dataprevistafim`,1 AS `datarealinicio`,1 AS `EntrId`,1 AS `EPT`,1 AS `Estoria`,1 AS `storypoints`,1 AS `kanban` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_sprintanteriorallativasembug`
--

/*!50001 DROP VIEW IF EXISTS `view_sprintanteriorallativasembug`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_sprintanteriorallativasembug` AS select 1 AS `referencia`,1 AS `SprintNome`,1 AS `SprintDataPlanning`,1 AS `DataInicio`,1 AS `Datafim`,1 AS `ItSprintId`,1 AS `SprintId`,1 AS `taskmain`,1 AS `tasksub`,1 AS `taskprincipal`,1 AS `storyppoints`,1 AS `storypointsrevised`,1 AS `storypointsoriginal`,1 AS `descricao`,1 AS `produto`,1 AS `entrega`,1 AS `Kanban`,1 AS `datarealizada`,1 AS `created`,1 AS `planejado`,1 AS `referfull`,1 AS `StoryPointsSub`,1 AS `prioridade`,1 AS `ultimadataalteracao`,1 AS `parkingday` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_sprintallativasembug`
--

/*!50001 DROP VIEW IF EXISTS `view_sprintallativasembug`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_sprintallativasembug` AS select 1 AS `referencia`,1 AS `SprintNome`,1 AS `SprintDataPlanning`,1 AS `DataInicio`,1 AS `Datafim`,1 AS `ItSprintId`,1 AS `SprintId`,1 AS `taskmain`,1 AS `tasksub`,1 AS `taskprincipal`,1 AS `storyppoints`,1 AS `storypointsrevised`,1 AS `storypointsoriginal`,1 AS `descricao`,1 AS `produto`,1 AS `entrega`,1 AS `Kanban`,1 AS `datarealizada`,1 AS `created`,1 AS `planejado`,1 AS `referfull`,1 AS `StoryPointsSub`,1 AS `prioridade`,1 AS `ultimadataalteracao`,1 AS `parkingday` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_statusreport_v1`
--

/*!50001 DROP VIEW IF EXISTS `view_statusreport_v1`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_statusreport_v1` AS select 1 AS `projid`,1 AS `projeto`,1 AS `prjDataPrevInicio`,1 AS `prjDataPrevFim`,1 AS `prjRealizadaFim`,1 AS `prodid`,1 AS `produto`,1 AS `prdStatus`,1 AS `prio`,1 AS `PrdDataPrevInicio`,1 AS `PrdDataPrevFim`,1 AS `PrdDataRealizada`,1 AS `ept`,1 AS `estoria`,1 AS `EntrRespond`,1 AS `sprintoriginal`,1 AS `datacriacaooriginal`,1 AS `criado_dia`,1 AS `criado_mes`,1 AS `criado_ano`,1 AS `kanban`,1 AS `cor`,1 AS `PmStatusgerencial` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_sprintsubtaskunplanned`
--

/*!50001 DROP VIEW IF EXISTS `view_sprintsubtaskunplanned`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_sprintsubtaskunplanned` AS select 1 AS `referencia`,1 AS `SprintNome`,1 AS `SprintDataPlanning`,1 AS `DataInicio`,1 AS `Datafim`,1 AS `ItSprintId`,1 AS `SprintId`,1 AS `taskmain`,1 AS `tasksub`,1 AS `taskprincipal`,1 AS `storyppoints`,1 AS `storypointsrevised`,1 AS `storypointsoriginal`,1 AS `descricao`,1 AS `produto`,1 AS `entrega`,1 AS `Kanban`,1 AS `datarealizada`,1 AS `created`,1 AS `planejado`,1 AS `referfull`,1 AS `StoryPointsSub`,1 AS `prioridade`,1 AS `ultimadataalteracao`,1 AS `parkingday` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_entregasparetolastid`
--

/*!50001 DROP VIEW IF EXISTS `view_entregasparetolastid`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_entregasparetolastid` AS select `projetosentregasparetos`.`projetosprodutosentrega_id` AS `projetosprodutosentrega_id`,max(`projetosentregasparetos`.`id`) AS `UlId` from `projetosentregasparetos` group by `projetosentregasparetos`.`projetosprodutosentrega_id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_contribute_per_sprint`
--

/*!50001 DROP VIEW IF EXISTS `view_contribute_per_sprint`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_contribute_per_sprint` AS select 1 AS `projetosprodutosentrega_id`,1 AS `referencia`,1 AS `responsabilidade_id`,1 AS `projetossprint_id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_sprintallativacomexperimentocalculo`
--

/*!50001 DROP VIEW IF EXISTS `view_sprintallativacomexperimentocalculo`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_sprintallativacomexperimentocalculo` AS select 1 AS `referencia`,1 AS `SprintNome`,1 AS `SprintDataPlanning`,1 AS `DataInicio`,1 AS `Datafim`,1 AS `ItSprintId`,1 AS `SprintId`,1 AS `taskmain`,1 AS `tasksub`,1 AS `taskprincipal`,1 AS `storyppoints`,1 AS `storypointsrevised`,1 AS `storypointsoriginal`,1 AS `descricao`,1 AS `produto`,1 AS `entrega`,1 AS `Kanban`,1 AS `datarealizada`,1 AS `created`,1 AS `planejado`,1 AS `referfull`,1 AS `StoryPointsSub`,1 AS `prioridade`,1 AS `ultimadataalteracao`,1 AS `parkingday` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_sistemasativos`
--

/*!50001 DROP VIEW IF EXISTS `view_sistemasativos`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_sistemasativos` AS select 1 AS `id`,1 AS `codenome`,1 AS `prio` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_paretosentregas`
--

/*!50001 DROP VIEW IF EXISTS `view_paretosentregas`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_paretosentregas` AS select 1 AS `pareto_id`,1 AS `dataatualizada`,1 AS `projetosprodutosentrega_id`,1 AS `ultimoid` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_5w3h_v1`
--

/*!50001 DROP VIEW IF EXISTS `v_5w3h_v1`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_5w3h_v1` AS select 1 AS `StatusAtiv`,1 AS `FiveId`,1 AS `Lancto`,1 AS `descricao`,1 AS `quem`,1 AS `quando`,1 AS `resolvidoem`,1 AS `oque`,1 AS `porque`,1 AS `como`,1 AS `lancadoem`,1 AS `acao`,1 AS `programa`,1 AS `projeto`,1 AS `produtocode`,1 AS `produtodesc`,1 AS `responsavel`,1 AS `consultor`,1 AS `ProgramaId`,1 AS `ProjetoId`,1 AS `ParticipanteId`,1 AS `ConsultorId`,1 AS `ProdutoId`,1 AS `StatusId`,1 AS `DiasOcorrencia`,1 AS `EfetuadoEm` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_retroist`
--

/*!50001 DROP VIEW IF EXISTS `view_retroist`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_retroist` AS select 1 AS `SprintId`,1 AS `SprintNome`,1 AS `RetroId`,1 AS `DataRetro`,1 AS `StatusRetro`,1 AS `ResumoRetro`,1 AS `referencia`,1 AS `ObsRetro`,1 AS `RetroCreated`,1 AS `ParetoId`,1 AS `Pareto`,1 AS `ItRetroId`,1 AS `ItemResumo`,1 AS `geraplanoacao`,1 AS `referenciaoriginal`,1 AS `classificacao` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_projetosparetosreduzido`
--

/*!50001 DROP VIEW IF EXISTS `view_projetosparetosreduzido`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_projetosparetosreduzido` AS select 1 AS `id`,1 AS `projeto_id`,1 AS `created`,1 AS `Kanban`,1 AS `Icon`,1 AS `agenda` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_projetosprodutosriscos`
--

/*!50001 DROP VIEW IF EXISTS `view_projetosprodutosriscos`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_projetosprodutosriscos` AS select 1 AS `id`,1 AS `PrjId`,1 AS `produto`,1 AS `prd_id`,1 AS `riscopadrao`,1 AS `aplicabilidade`,1 AS `probabilidade`,1 AS `severidade`,1 AS `nivel`,1 AS `resumo`,1 AS `detalhes`,1 AS `indicadorseveridade`,1 AS `indicadorprobabilidade`,1 AS `created` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_sprinttempodetestes`
--

/*!50001 DROP VIEW IF EXISTS `view_sprinttempodetestes`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_sprinttempodetestes` AS select 1 AS `sprint`,1 AS `datainicio`,1 AS `datafim`,1 AS `produto`,1 AS `projeto`,1 AS `TmpTotalTestes` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_sprintsubtasks`
--

/*!50001 DROP VIEW IF EXISTS `view_sprintsubtasks`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_sprintsubtasks` AS select 1 AS `id`,1 AS `projetossprint_id`,1 AS `projetosprodutosentrega_id`,1 AS `referencia`,1 AS `taskmain`,1 AS `tasksub`,1 AS `dataplanning`,1 AS `storyppoints`,1 AS `statusfuncional_id`,1 AS `created`,1 AS `modified`,1 AS `storypointsrevised`,1 AS `datarevised`,1 AS `pareto_id`,1 AS `datainiciovalidacao`,1 AS `taskprincipal`,1 AS `subtask`,1 AS `storypointsoriginal`,1 AS `datarealizada`,1 AS `planejado`,1 AS `unidademedida`,1 AS `datatestelimite`,1 AS `datatesteprevista`,1 AS `horastestesestimadas`,1 AS `storypointsreview`,1 AS `prioridade`,1 AS `dataultimaalteracao`,1 AS `sprintoriginal`,1 AS `sprintoriginal_id`,1 AS `calculoexperimental`,1 AS `canceladoem`,1 AS `cancelado`,1 AS `canceladomotivo` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_agenda`
--

/*!50001 DROP VIEW IF EXISTS `view_agenda`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_agenda` AS select 1 AS `seq`,1 AS `data`,1 AS `mesnome`,1 AS `dianome`,1 AS `dia`,1 AS `mes`,1 AS `ano`,1 AS `horainicio`,1 AS `horafim`,1 AS `WeeK`,1 AS `diaserial`,1 AS `tipoagenda`,1 AS `evento`,1 AS `projeto`,1 AS `atividade` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_projetotimings`
--

/*!50001 DROP VIEW IF EXISTS `view_projetotimings`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_projetotimings` AS select 1 AS `projeto_id`,1 AS `descricao`,1 AS `datainicio`,1 AS `datafim`,1 AS `created`,1 AS `modified`,1 AS `tmpdisponiveldadata`,1 AS `tmpdisponiveldehoje`,1 AS `tmpaberturadadata`,1 AS `tmpaberturaddehoje`,1 AS `totaldediasuteisdadata`,1 AS `totaldediasuteisdehoje` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_queue_running_functests_v2`
--

/*!50001 DROP VIEW IF EXISTS `view_queue_running_functests_v2`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_queue_running_functests_v2` AS select 1 AS `entregaId`,1 AS `produtoid`,1 AS `referencia`,1 AS `descricao`,1 AS `Kanban`,1 AS `datacriacaooriginal`,1 AS `datarealizada`,1 AS `prioridade`,1 AS `responsavel`,1 AS `atendidopor`,1 AS `sprintoriginal`,1 AS `subtasks`,1 AS `tipo`,1 AS `aging`,1 AS `created`,1 AS `modified` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_painelsprints_v0`
--

/*!50001 DROP VIEW IF EXISTS `view_painelsprints_v0`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_painelsprints_v0` AS select 1 AS `sprintoriginal`,1 AS `TotalTasks`,1 AS `TotalStoryPoints` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_feedbacksprints`
--

/*!50001 DROP VIEW IF EXISTS `view_feedbacksprints`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_feedbacksprints` AS select 1 AS `programa`,1 AS `sprint`,1 AS `projetoid`,1 AS `projeto`,1 AS `produto`,1 AS `datainicio`,1 AS `datafim`,1 AS `SprItId`,1 AS `dataplanning`,1 AS `ept`,1 AS `descricao`,1 AS `kanban` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_kanbanentregas`
--

/*!50001 DROP VIEW IF EXISTS `view_kanbanentregas`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_kanbanentregas` AS select 1 AS `produto_id`,1 AS `produto`,1 AS `prioproduto`,1 AS `entrega_id`,1 AS `entrega`,1 AS `prioentrega`,1 AS `entregapareto_id`,1 AS `projetosprodutosentrega_id`,1 AS `pareto_id`,1 AS `Kanban`,1 AS `created`,1 AS `motivo`,1 AS `tmpprevisto`,1 AS `dataprevista` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_sprintativa`
--

/*!50001 DROP VIEW IF EXISTS `view_sprintativa`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_sprintativa` AS select 1 AS `referencia`,1 AS `SprintNome`,1 AS `SprintDataPlanning`,1 AS `DataInicio`,1 AS `Datafim`,1 AS `ItSprintId`,1 AS `SprintId`,1 AS `taskmain`,1 AS `tasksub`,1 AS `taskprincipal`,1 AS `storyppoints`,1 AS `storypointsrevised`,1 AS `storypointsoriginal`,1 AS `descricao`,1 AS `produto`,1 AS `entrega`,1 AS `Kanban`,1 AS `datarealizada`,1 AS `created`,1 AS `datatestelimite`,1 AS `horasestimadas`,1 AS `planejado`,1 AS `prio`,1 AS `ultimadataalteracao`,1 AS `parkingday`,1 AS `sprintoriginal` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `viewpaineldeferias`
--

/*!50001 DROP VIEW IF EXISTS `viewpaineldeferias`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `viewpaineldeferias` AS select 1 AS `resumo`,1 AS `projeto_id`,1 AS `perfil`,1 AS `percentual`,1 AS `tempo`,1 AS `previstorealizado`,1 AS `semananumero`,1 AS `mes`,1 AS `mesnome`,1 AS `TmpTotal` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_queue_sprints_v1`
--

/*!50001 DROP VIEW IF EXISTS `view_queue_sprints_v1`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_queue_sprints_v1` AS select 1 AS `entregaId`,1 AS `produtoid`,1 AS `referencia`,1 AS `descricao`,1 AS `Kanban`,1 AS `datacriacaooriginal`,1 AS `datarealizada`,1 AS `prioridade`,1 AS `responsavel`,1 AS `atendidopor`,1 AS `sprintoriginal`,1 AS `subtasks`,1 AS `tipo`,1 AS `aging`,1 AS `created`,1 AS `modified` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_prjsprintspontuacao`
--

/*!50001 DROP VIEW IF EXISTS `view_prjsprintspontuacao`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_prjsprintspontuacao` AS select 1 AS `sprint`,1 AS `EPT`,1 AS `Planejado`,1 AS `PointReview`,1 AS `Revisado` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_paretosentregas`
--

/*!50001 DROP VIEW IF EXISTS `v_paretosentregas`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_paretosentregas` AS select 1 AS `pareto_id`,1 AS `dataatualizada`,1 AS `projetosprodutosentrega_id`,1 AS `ultimoid` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_queue_running_functests`
--

/*!50001 DROP VIEW IF EXISTS `view_queue_running_functests`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_queue_running_functests` AS select 1 AS `entregaId`,1 AS `produtoid`,1 AS `referencia`,1 AS `descricao`,1 AS `Kanban`,1 AS `datacriacaooriginal`,1 AS `criacaodia`,1 AS `criacaomes`,1 AS `criacaoano`,1 AS `datarealizada`,1 AS `prioridade`,1 AS `responsavel`,1 AS `atendidopor`,1 AS `sprintoriginal`,1 AS `subtasks`,1 AS `created`,1 AS `modified` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_sprintitensprincipais`
--

/*!50001 DROP VIEW IF EXISTS `view_sprintitensprincipais`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_sprintitensprincipais` AS select 1 AS `id`,1 AS `sprid`,1 AS `entrid`,1 AS `referencia`,1 AS `planejado`,1 AS `sprintoriginal` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_valorestoriasprincipais`
--

/*!50001 DROP VIEW IF EXISTS `view_valorestoriasprincipais`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_valorestoriasprincipais` AS select 1 AS `taskprincipal`,1 AS `Estorias`,1 AS `Total` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_contribute_per_support`
--

/*!50001 DROP VIEW IF EXISTS `view_contribute_per_support`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_contribute_per_support` AS select 1 AS `projetosprodutosentrega_id`,1 AS `referencia`,1 AS `responsabilidade_id`,1 AS `projetossprint_id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vwentregaultimopareto`
--

/*!50001 DROP VIEW IF EXISTS `vwentregaultimopareto`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vwentregaultimopareto` AS select 1 AS `EntregaId`,1 AS `ProdutoId`,1 AS `SistemaId`,1 AS `StatusId`,1 AS `created`,1 AS `UnMedidaId`,1 AS `prioridade`,1 AS `planolinha`,1 AS `FaseId`,1 AS `EmpresaId`,1 AS `AmbienteId`,1 AS `ordem`,1 AS `DeptoId`,1 AS `EntregaParetoId` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_prodentregaultimopareto`
--

/*!50001 DROP VIEW IF EXISTS `v_prodentregaultimopareto`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_prodentregaultimopareto` AS select 1 AS `EntregaId`,1 AS `ParetoId`,1 AS `UltAtualizacao` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_sprintporproduto`
--

/*!50001 DROP VIEW IF EXISTS `view_sprintporproduto`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_sprintporproduto` AS select 1 AS `produto`,1 AS `TtRefer`,1 AS `TotalPt` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_sprintmainunplaned`
--

/*!50001 DROP VIEW IF EXISTS `view_sprintmainunplaned`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_sprintmainunplaned` AS select 1 AS `referencia`,1 AS `SprintNome`,1 AS `SprintDataPlanning`,1 AS `DataInicio`,1 AS `Datafim`,1 AS `ItSprintId`,1 AS `SprintId`,1 AS `taskmain`,1 AS `tasksub`,1 AS `taskprincipal`,1 AS `storyppoints`,1 AS `storypointsrevised`,1 AS `storypointsoriginal`,1 AS `descricao`,1 AS `produto`,1 AS `entrega`,1 AS `Kanban`,1 AS `datarealizada`,1 AS `created`,1 AS `datatestelimite`,1 AS `horasestimadas`,1 AS `planejado`,1 AS `prio`,1 AS `ultimadataalteracao`,1 AS `parkingday`,1 AS `sprintoriginal` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_feedbacksprintrequisitos`
--

/*!50001 DROP VIEW IF EXISTS `view_feedbacksprintrequisitos`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_feedbacksprintrequisitos` AS select 1 AS `SprintNome`,1 AS `SprintDataPlanning`,1 AS `DataInicio`,1 AS `Datafim`,1 AS `programa`,1 AS `projeto`,1 AS `produto`,1 AS `entrega`,1 AS `referencia`,1 AS `Un`,1 AS `descricao`,1 AS `Kanban`,1 AS `datarealizada`,1 AS `created`,1 AS `datatestelimite`,1 AS `horasestimadas`,1 AS `planejado`,1 AS `prio`,1 AS `ultimadataalteracao`,1 AS `parkingday` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_painelprints_v1`
--

/*!50001 DROP VIEW IF EXISTS `view_painelprints_v1`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_painelprints_v1` AS select 1 AS `produto`,1 AS `sprintoriginal`,1 AS `TotalTasks`,1 AS `TotalStoryPoints` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_queue_no_priorized`
--

/*!50001 DROP VIEW IF EXISTS `view_queue_no_priorized`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_queue_no_priorized` AS select 1 AS `entregaId`,1 AS `produtoid`,1 AS `referencia`,1 AS `descricao`,1 AS `Kanban`,1 AS `datacriacaooriginal`,1 AS `datarealizada`,1 AS `prioridade`,1 AS `responsavel`,1 AS `atendidopor`,1 AS `sprintoriginal`,1 AS `subtasks`,1 AS `tipo`,1 AS `aging`,1 AS `created`,1 AS `modified` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_projetossprintdistpontoskanban`
--

/*!50001 DROP VIEW IF EXISTS `view_projetossprintdistpontoskanban`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_projetossprintdistpontoskanban` AS select 1 AS `SprintNome`,1 AS `SprintId`,1 AS `Kanban`,1 AS `TotalPts` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_sprintstoryreview`
--

/*!50001 DROP VIEW IF EXISTS `view_sprintstoryreview`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_sprintstoryreview` AS select 1 AS `projetossprint_id`,1 AS `projetosprodutosentrega_id`,1 AS `referencia`,1 AS `storyppoints`,1 AS `storypointsrevised`,1 AS `storypointsoriginal`,1 AS `storypointsreview`,1 AS `planejado`,1 AS `StoryPointsFinal` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-27 20:36:06
