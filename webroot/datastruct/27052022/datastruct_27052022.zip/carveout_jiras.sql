CREATE DATABASE  IF NOT EXISTS `carveout` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `carveout`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: carveout
-- ------------------------------------------------------
-- Server version	5.7.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `jiras`
--

DROP TABLE IF EXISTS `jiras`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jiras` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_IssueReport` varchar(255) DEFAULT NULL,
  `task_Data` date DEFAULT NULL,
  `task_Registros` decimal(18,4) DEFAULT '0.0000',
  `task_Key` varchar(10) DEFAULT NULL,
  `task_DescricaoSistema` varchar(255) DEFAULT NULL,
  `task_SystemName` varchar(255) DEFAULT NULL,
  `task_TestStatusComment` varchar(255) DEFAULT NULL,
  `task_FixVersions` varchar(255) DEFAULT NULL,
  `task_AffectsVersions` varchar(255) DEFAULT NULL,
  `task_Assignee` varchar(255) DEFAULT NULL,
  `task_Components` varchar(255) DEFAULT NULL,
  `task_Created` varchar(255) DEFAULT NULL,
  `task_Creator` varchar(255) DEFAULT NULL,
  `task_Description` longtext,
  `task_DueDate` varchar(255) DEFAULT NULL,
  `task_Images` longtext,
  `task_IssueType` varchar(255) DEFAULT NULL,
  `task_LinkedIssues` varchar(255) DEFAULT NULL,
  `task_OriginalEstimate` varchar(255) DEFAULT NULL,
  `task_PrazoOriginal` varchar(255) DEFAULT NULL,
  `task_Priority` varchar(255) DEFAULT NULL,
  `task_Project` varchar(255) DEFAULT NULL,
  `task_ReasonforDueDate` varchar(255) DEFAULT NULL,
  `task_RemainingEstimate` varchar(255) DEFAULT NULL,
  `task_Reporter` varchar(255) DEFAULT NULL,
  `task_Resolution` varchar(255) DEFAULT NULL,
  `task_Resolved` varchar(255) DEFAULT NULL,
  `task_Sprint` varchar(255) DEFAULT NULL,
  `task_Status` varchar(255) DEFAULT NULL,
  `task_Summary` varchar(255) DEFAULT NULL,
  `task_TimeSpent` varchar(255) DEFAULT NULL,
  `task_Updated` varchar(255) DEFAULT NULL,
  `task_Watchers` varchar(255) DEFAULT NULL,
  `task_Labels` varchar(255) DEFAULT NULL,
  `task_StoryPoints` varchar(10) DEFAULT '0.0000',
  `task_StoryPointsReview` varchar(20) DEFAULT '0.0000',
  `task_AffectedSystem` varchar(255) DEFAULT NULL,
  `task_ApplicationModule` varchar(255) DEFAULT NULL,
  `task_ApplicationName` varchar(255) DEFAULT NULL,
  `task_DueDate1` varchar(255) DEFAULT NULL,
  `task_SystemName2` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `processado` int(11) DEFAULT '0',
  `task_Subtasks` longtext,
  `task_flagged` varchar(255) DEFAULT NULL,
  `task_integrationstatus` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_jiraskey` (`task_Key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-27 20:36:00
