CREATE DATABASE  IF NOT EXISTS `carveout` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `carveout`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: carveout
-- ------------------------------------------------------
-- Server version	5.7.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `kronusitems`
--

DROP TABLE IF EXISTS `kronusitems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kronusitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kronusplan_id` int(11) DEFAULT NULL,
  `kronu_id` int(11) DEFAULT NULL,
  `kickoff` date DEFAULT NULL,
  `seq` int(11) DEFAULT NULL,
  `ordem` int(11) DEFAULT NULL,
  `edt` varchar(15) DEFAULT NULL,
  `consultore_id` int(11) DEFAULT NULL,
  `categoria` varchar(45) DEFAULT NULL,
  `nometarefa` varchar(255) DEFAULT NULL,
  `etapa` varchar(10) DEFAULT NULL,
  `percconcluido` decimal(18,4) DEFAULT NULL,
  `duracao` decimal(18,4) DEFAULT NULL,
  `unidademedida_id` int(11) DEFAULT NULL,
  `inicio` date DEFAULT NULL,
  `fim` date DEFAULT NULL,
  `predecessora` int(11) DEFAULT NULL,
  `nomerecurso` varchar(150) DEFAULT NULL,
  `idexclusivo` int(11) DEFAULT NULL,
  `dataatualizacao` date DEFAULT NULL,
  `versao` int(11) DEFAULT '1',
  `nivel1` int(11) DEFAULT NULL,
  `nivel2` int(11) DEFAULT NULL,
  `nivel3` int(11) DEFAULT NULL,
  `nivel4` int(11) DEFAULT NULL,
  `nivel5` int(11) DEFAULT NULL,
  `nivel6` int(11) DEFAULT NULL,
  `nivel7` int(11) DEFAULT NULL,
  `nivel8` int(11) DEFAULT NULL,
  `nivel9` int(11) DEFAULT NULL,
  `nivel10` int(11) DEFAULT NULL,
  `projetosproduto_id` int(11) DEFAULT NULL,
  `projetosprodutosentrega_id` int(11) DEFAULT NULL,
  `projeto_id` int(11) DEFAULT NULL,
  `apontamento` int(11) DEFAULT '1',
  `pareto_id` int(11) DEFAULT '1',
  `milestone` varchar(10) DEFAULT '0',
  `decisorio` int(11) DEFAULT '0',
  `selecao` int(11) DEFAULT '0',
  `resumo` varchar(255) DEFAULT NULL,
  `objetivo` longtext,
  `referencia` varchar(45) DEFAULT NULL,
  `flagname` varchar(45) DEFAULT NULL,
  `flag_id` int(11) DEFAULT NULL,
  `fase_id` int(11) DEFAULT NULL,
  `responsavel` varchar(45) DEFAULT NULL,
  `atividade` varchar(255) DEFAULT NULL,
  `comentario` varchar(255) DEFAULT NULL,
  `criticidade` varchar(45) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `fasenome` varchar(45) DEFAULT NULL,
  `previstodatainicio` date DEFAULT NULL,
  `previstodatafinal` date DEFAULT NULL,
  `previstoduracao` decimal(18,4) DEFAULT NULL,
  `realizadodatainicio` date DEFAULT NULL,
  `realizadodatafinal` date DEFAULT NULL,
  `realizadoduracao` decimal(18,4) DEFAULT NULL,
  `kpi` int(11) DEFAULT NULL,
  `referenciaatividade` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13089 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-27 20:35:44
