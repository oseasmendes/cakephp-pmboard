CREATE DATABASE  IF NOT EXISTS `saesassets` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `saesassets`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: saesassets
-- ------------------------------------------------------
-- Server version	5.7.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `assetsequipmachs`
--

DROP TABLE IF EXISTS `assetsequipmachs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assetsequipmachs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `assetsbook_id` int(11) DEFAULT NULL,
  `item_id` int(11) DEFAULT NULL,
  `description` varchar(180) DEFAULT NULL,
  `brand` varchar(45) DEFAULT NULL,
  `model` varchar(45) DEFAULT NULL,
  `manufacture` varchar(45) DEFAULT NULL,
  `lifecycle` int(11) DEFAULT NULL,
  `preservationstate_id` int(11) DEFAULT NULL,
  `localization` varchar(45) DEFAULT NULL,
  `equipmentstype_id` int(11) DEFAULT NULL,
  `serialnumber` varchar(45) DEFAULT NULL,
  `servicenumber` varchar(45) DEFAULT NULL,
  `colordescription` varchar(45) DEFAULT NULL,
  `aquisitiondate` date DEFAULT NULL,
  `aquisitiontype_id` int(11) DEFAULT NULL,
  `aquisitionvalue` decimal(18,4) DEFAULT NULL,
  `aquisitiondocnumer` varchar(45) DEFAULT NULL,
  `aquisitiondoctype_id` int(11) DEFAULT NULL,
  `warrantyhave` tinyint(1) DEFAULT NULL,
  `warrantyexpirationdate` date DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_aequip_book_idx` (`assetsbook_id`),
  KEY `fk_aequip_preservation_idx` (`preservationstate_id`),
  KEY `fk_aequip_type_idx` (`equipmentstype_id`),
  KEY `fk_aequip_aqutype_idx` (`aquisitiontype_id`),
  KEY `fk_aequip_docstype_idx` (`aquisitiondoctype_id`),
  KEY `fk_aequip_item_idx` (`item_id`),
  CONSTRAINT `fk_aequip_aqutype` FOREIGN KEY (`aquisitiontype_id`) REFERENCES `aquisitiontypes` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_aequip_book` FOREIGN KEY (`assetsbook_id`) REFERENCES `assetsbooks` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_aequip_docstype` FOREIGN KEY (`aquisitiondoctype_id`) REFERENCES `aquisitiondoctypes` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_aequip_item` FOREIGN KEY (`item_id`) REFERENCES `items` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_aequip_preservation` FOREIGN KEY (`preservationstate_id`) REFERENCES `preservationstates` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_aequip_type` FOREIGN KEY (`equipmentstype_id`) REFERENCES `equipmentstypes` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-07-05 20:43:05
