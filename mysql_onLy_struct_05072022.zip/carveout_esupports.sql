CREATE DATABASE  IF NOT EXISTS `carveout` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `carveout`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: carveout
-- ------------------------------------------------------
-- Server version	5.7.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `esupports`
--

DROP TABLE IF EXISTS `esupports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `esupports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `origid` varchar(20) DEFAULT NULL,
  `datadecriacao` varchar(20) DEFAULT NULL,
  `titulo` varchar(250) DEFAULT NULL,
  `descricao` longtext,
  `situacaoatual` longtext,
  `beneficios` longtext,
  `focus5` varchar(250) DEFAULT NULL,
  `prioridade` varchar(10) DEFAULT NULL,
  `requisitante` varchar(250) DEFAULT NULL,
  `gestor` varchar(250) DEFAULT NULL,
  `local` varchar(250) DEFAULT NULL,
  `departamento` varchar(250) DEFAULT NULL,
  `aplicacao` varchar(250) DEFAULT NULL,
  `statusdetalhado` varchar(250) DEFAULT NULL,
  `categoria` varchar(15) DEFAULT NULL,
  `complexidade` varchar(15) DEFAULT NULL,
  `atribuidopara` varchar(250) DEFAULT NULL,
  `atribuidoem` varchar(20) DEFAULT NULL,
  `statusatual` varchar(50) DEFAULT NULL,
  `dataenviodesenvolvimento` varchar(20) DEFAULT NULL,
  `dataretornodesenvolvedor` varchar(20) DEFAULT NULL,
  `dataenvioparateste` varchar(20) DEFAULT NULL,
  `dataretornoteste` varchar(20) DEFAULT NULL,
  `datacab` varchar(20) DEFAULT NULL,
  `dataprevistadeimplementacao` varchar(20) DEFAULT NULL,
  `datadeconclusao` varchar(20) DEFAULT NULL,
  `dataimplementacaoemproducao` varchar(20) DEFAULT NULL,
  `kpi` varchar(2) DEFAULT NULL,
  `createdby` varchar(100) DEFAULT NULL,
  `modifiedby` varchar(100) DEFAULT NULL,
  `equipeti` varchar(20) DEFAULT NULL,
  `categoriaba` varchar(80) DEFAULT NULL,
  `itemtype` varchar(10) DEFAULT NULL,
  `path` varchar(250) DEFAULT NULL,
  `processado` int(11) DEFAULT '1',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `dataescopofechamento` varchar(20) DEFAULT NULL,
  `datalancto` datetime DEFAULT NULL,
  `dataprevistadeconclusao` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_esupp_attribpara` (`atribuidopara`)
) ENGINE=MyISAM AUTO_INCREMENT=57447 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-07-05 20:42:50
