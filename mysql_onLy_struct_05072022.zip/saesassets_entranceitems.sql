CREATE DATABASE  IF NOT EXISTS `saesassets` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `saesassets`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: saesassets
-- ------------------------------------------------------
-- Server version	5.7.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `entranceitems`
--

DROP TABLE IF EXISTS `entranceitems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entranceitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entrancedoc_id` int(11) DEFAULT NULL,
  `accoutingcode` varchar(45) NOT NULL,
  `businessunit_id` int(11) DEFAULT NULL,
  `item_id` int(11) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `data` date DEFAULT NULL,
  `qty` decimal(18,5) DEFAULT NULL,
  `docentrydate` varchar(45) DEFAULT NULL,
  `docentrytype_id` int(11) DEFAULT NULL,
  `docentryvalue` decimal(18,4) DEFAULT NULL,
  `docentryreference` varchar(45) DEFAULT NULL,
  `docentryitemvalue` decimal(18,4) DEFAULT NULL,
  `operation` varchar(1) DEFAULT NULL,
  `itemnumber` varchar(45) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `changeby` int(11) DEFAULT NULL,
  `entryequipmentscol` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`,`accoutingcode`),
  KEY `fk_entranceitems_entrytype_idx` (`docentrytype_id`),
  KEY `fk_entranceitems_itens_idx` (`item_id`),
  KEY `fk_entranceitems_docs_idx` (`entrancedoc_id`),
  CONSTRAINT `fk_entranceitems_docs0` FOREIGN KEY (`entrancedoc_id`) REFERENCES `entrancedocs` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_entranceitems_entrytype0` FOREIGN KEY (`docentrytype_id`) REFERENCES `docentrytypes` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_entranceitems_itens0` FOREIGN KEY (`item_id`) REFERENCES `items` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-07-05 20:43:05
