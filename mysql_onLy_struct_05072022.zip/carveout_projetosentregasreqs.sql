CREATE DATABASE  IF NOT EXISTS `carveout` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `carveout`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: carveout
-- ------------------------------------------------------
-- Server version	5.7.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `projetosentregasreqs`
--

DROP TABLE IF EXISTS `projetosentregasreqs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projetosentregasreqs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `projetosprodutosentrega_id` int(11) DEFAULT NULL,
  `entregastipo_id` int(11) DEFAULT NULL,
  `processo_id` int(11) DEFAULT NULL,
  `participante_id` int(11) DEFAULT NULL,
  `dataemissao` date DEFAULT NULL,
  `solicitante` varchar(255) DEFAULT NULL,
  `wave` int(11) DEFAULT NULL,
  `prioridade` int(11) DEFAULT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  `detalhes` longtext,
  `previsaoanalise` decimal(18,4) DEFAULT NULL,
  `previsaosprints` int(11) DEFAULT NULL,
  `statusfuncional_id` int(11) DEFAULT NULL,
  `consultore_id` int(11) DEFAULT NULL,
  `unidademedida_id` int(11) DEFAULT NULL,
  `referencia` varchar(25) DEFAULT NULL,
  `frente_id` int(11) DEFAULT NULL,
  `ativo` tinyint(1) DEFAULT NULL,
  `reqstatus` varchar(45) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `ordem` int(11) DEFAULT NULL,
  `objetivo` longtext,
  `origem` varchar(254) DEFAULT NULL,
  `sample` longtext,
  `regradenegocio` longtext,
  `developer_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-07-05 20:42:52
